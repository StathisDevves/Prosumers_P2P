# FixedOmega - 36 calculated Excel outputs

Sensitivity: alpha = 0.20 / 0.25 / 0.30 EUR/kWh^2. The same fixed 24-hour omega profile is used in all cases; no price/load recalibration.

Hours 1-6: 0.55; 7-10: 1.00; 11-16: 0.80; 17-22: 1.35; 23: 0.65; 24: 0.55 EUR/kWh.

Three strategies and four capacities (10, 15, 20, 30 kWh) give 36 cases over the same 8,760 supplied 2025 hours.

## Workbook map
Summary; Parameters; Model_Notes; Solar_8760_2025; Dispatch; Daily_Summary; Monthly_Summary; QA; Monthly_Profile; Omega_Profile.

Hourly evaluation and daily/monthly/annual aggregations contain Excel formulas and precomputed numeric caches. Dispatch is a Python-result snapshot. Editing alpha or omega in Excel alone does not re-optimize physical dispatch; rerun Python.

### Purpose
36 deterministic cases: alpha 0.20/0.25/0.30 x A/B/C x 10/15/20/30 kWh. Same supplied 2025 inputs.

### Fixed preference profile
omega_t is prescribed by hour and is independent of alpha and prices. Hours 1-6 and 24: 0.55; 7-10: 1.00; 11-16: 0.80; 17-22: 1.35; 23: 0.65 EUR/kWh. The price-plus-load calibration equation is not used.

### Reference data
The supplied 2025 price/PV/base-load inputs are unchanged. Alpha=0.25 is the baseline of this fixed-profile corrected-v4 experiment, not a reproduction guarantee for the pre-review model.

### Version and comparison
v5 FixedOmega retains corrected v4 dispatch and economic formulas but replaces the recalibrated omega with the agreed fixed table. Keep these outputs separate from both v4 recalibrated and pre-review outputs.

### Excel interpretation
Dispatch sheet holds Python controller/solver snapshots. Hourly evaluation and aggregations use Excel formulas. RERUN PYTHON after changing inputs or scenario parameters; Excel alone does not re-optimize dispatch.

### Strategy A
Calendar-day min/max thresholds (shares 1/3 and 2/3); PV-only charging; discharge to load. Continuous SOC, no daily reset. Discharge takes precedence if charge and discharge rules overlap.

### Strategy B
24-hour look-ahead price min/max thresholds (shares 0.30/0.70); PV/grid charging; battery export; 30% evening discharge reserve, 10% otherwise. Continuous SOC and no simultaneous charge/discharge.

### Strategy C
Re-optimizes at every hour over the next min(24, remaining) records; applies only the first decision. Cost/proxy-incentive objective, not maximization of the reported utility/welfare indicators.

### C objective corrections
PV charging includes forgone proxy export revenue. Peak proxy penalty applies to grid charging too. Discharge/charge complementarity is enforced; LP solutions are accepted only when complementarity holds, otherwise binary-mode HiGHS MIP is solved.

### C alpha interpretation
Base load is fixed and direct PV consumption equals min(load, PV). Neither alpha nor omega enters C dispatch. Dispatch is reused across alpha cases; only ex-post utility/welfare valuation changes.

### Forecast assumption
B/C use the supplied look-ahead trajectory as perfect information within the window. There is no forecast-error model. A also uses full calendar-day price extrema.

### Self-discharge convention
Hourly self-discharge acts on usable energy above the minimum non-dispatchable reserve. This explicitly avoids silently creating energy by clamping an under-minimum SOC.

### Physical accounting
Grid-to-load and grid-to-battery are separated. E_actual excludes grid charging. Base household demand remains served; this is not a newly implemented endogenous load-curtailment model.

### Degradation
Cost = psi x (charge + discharge), AC-side throughput. No capacity fade is simulated. Both charging and discharging incur cost; the original absolute-net formula is not used.

### Initial and terminal energy
All start at 90%. C has 90% end-of-window target and 90% year-end SOC. A/B have no forced year-end target. Final-minus-initial inventory is reported; policy comparisons are not pure controller-intelligence tests.

### Reported EQ14 and net utility
AO retains the original EQ14 expression, which omits grid-purchase cost. BT provides AO minus grid cost. Do not label AO a complete net P2P profit.

### Reported welfare formulas
AU, AY/AZ/BC, BD/BG/BH retain the source algebra as diagnostic indicators. Economic definitions, proxy costs and common utility calibration require review before journal interpretation. Technical QA is NOT economic/field validation.

### PS_to_grid arithmetic
BJ = AU - BG is preserved as the requested arithmetic indicator. AU contains P2P injection/premium/network terms; this subtraction alone does not prove a pure pre-P2P welfare decomposition.

### P2P transaction scope
All available exports are used as a P2P injection proxy in ex-post evaluation; grid-sale and P2P-sale amounts are alternative valuations, not additive simultaneous sales.

### P2P participation limitation
No buyer demand cap, outside option or individual-rationality constraint is enforced. Negative buyer utility/marginal utility is retained and counted, not clipped or hidden.

### P2P price numerical rule
Source hyperbolic SDR formula retained, with SDR capped at one. Zero/near-zero denominator falls back to spot price and is counted; negative prices are retained. It is not a validated double-auction clearing rule.

### Utility-indifference price
AX equals AW/(2*injection) when injection exceeds tolerance, otherwise blank. AX is diagnostic, not the dispatch or implemented transaction price. No feasible-price bounds are silently imposed.

### Elasticity limitation
Y is the original -price/(alpha x grid-to-load) proxy, reported as zero at zero/near-zero import. It is NOT a newly estimated causal elasticity of optimized net imports. CD marks where this proxy is defined.

### Numerical verification
Fixed omega profile, balance, SOC continuity/bounds, power, complementarity and two algebraic utility identities are tested. Technical PASS is not economic or field validation.

### Source input year
Input timestamps form a continuous 2025 calendar. Prices are used as supplied by the user; their historical provenance is not independently re-downloaded here.

### Downstream studies
This run varies only alpha at fixed omega. No new price year, independent omega variation, degradation sensitivity, Fourier analysis or field validation is introduced.

### Solver documentation
https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html

### Source code
Parent: build_EQ1_EQ32_AlphaSensitivity_v4.py. FixedOmega changes are documented in CHANGELOG_FixedOmega.md. Original input and code files are not overwritten.

### Hourly convention
Use the existing dataset labels 1..24. Hour 24 remains 0.55 EUR/kWh; no shift to a different clock convention is made.

## Reproduction
Run `python build_EQ1_EQ32_FixedOmega_Sensitivity_v5.py --input-data "Input Data.xlsx" --core-assumptions "Input Core assumptions.xlsx"`. Only the two input Excel files are required. Runtime dependencies: NumPy and SciPy; standard-library ZIP/XML handles the embedded workbook template. No Google Drive connection is required.

## Interpretation
Do not mix these FixedOmega results with the previous recalibrated-omega sensitivity charts. Fixed omega does not reverse the v4 physical corrections. Negative economic indicators are retained. The controller objective and economic limitations are unchanged.
