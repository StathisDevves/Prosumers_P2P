"""Deterministic alpha sensitivity model; revision v4, 22 September 2026.

Calibration: omega[t] = mean(24 supplied spot prices for day d) + alpha*base_load[t].
36 cases: three alpha values, three controllers, four storage capacities.
The evaluation formulas EQ1-EQ32 are retained as *reported indicators*, not
certified welfare accounts. See README and workbook Model_Notes for limitations.
"""
from __future__ import annotations
import argparse, calendar, hashlib, json, math, platform, sys, time, zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
import scipy
from scipy.optimize import linprog

NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def colname(k:int)->str:
    s=''
    while k:
        k,r=divmod(k-1,26);s=chr(65+r)+s
    return s

def read_xlsx_rows(path:Path, sheet:str|None=None):
    """Read stored numeric inputs using standard-library OOXML, no Excel engine.
    Formula inputs must have cached values; uncached formulas are rejected.
    """
    with zipfile.ZipFile(path) as z:
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets={r.attrib['Id']:r.attrib['Target'] for r in rel}
        sheets=wb.find('s:sheets',NS)
        sel=next((x for x in sheets if sheet is None or x.attrib['name']==sheet),None)
        if sel is None: raise ValueError(f'Sheet {sheet!r} not found in {path.name}')
        target=targets[sel.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]
        part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            shared=[''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        out=[]
        for row in ET.fromstring(z.read(part)).findall('.//s:sheetData/s:row',NS):
            r=int(row.attrib['r']);d={}
            for c in row:
                addr=c.attrib['r']; letters=''.join(x for x in addr if x.isalpha());k=0
                for l in letters:k=k*26+ord(l)-64
                typ=c.attrib.get('t'); v=c.find('s:v',NS)
                if typ=='inlineStr': value=''.join(c.find('s:is',NS).itertext())
                elif v is None:
                    if c.find('s:f',NS) is not None: raise ValueError(f'Uncached input formula {path.name}/{sheet}!{addr}')
                    value=None
                elif typ=='s': value=shared[int(v.text)]
                elif typ in ('str','e'): value=v.text
                else:
                    value=float(v.text) if v.text is not None else None
                    if value is not None and value.is_integer():value=int(value)
                d[k]=value
            while len(out)<r:out.append([])
            out[r-1]=[d.get(k) for k in range(1,max(d,default=0)+1)]
        return out

@dataclass(frozen=True)
class Settings:
    pv_area:float=50.0
    pv_efficiency:float=0.18
    eta_ch:float=0.92
    eta_dis:float=0.92
    p_ch:float=3.0
    p_dis:float=3.0
    soc0:float=0.90
    soc_min:float=0.10
    soc_max:float=1.00
    sigma:float=0.00002
    psi:float=0.03
    zeta:float=0.20
    tau_base:float=0.05
    theta:float=0.022
    rho:float=1.0
    b_i:float=0.065
    a_i:float=0.025
    a1_min:float=0.10
    a1_max:float=0.50
    low:float=1/3
    high:float=2/3
    adaptive_low:float=0.30
    adaptive_high:float=0.70
    reserve_base:float=0.10
    reserve_evening:float=0.30
    arb_margin:float=0.01
    grid_charge_limit:float=3.0
    sell_limit:float=3.0
    peak_penalty:float=0.04
    self_reward:float=0.02
    export_factor:float=0.80
    numeric_tol:float=1e-9
    qa_tol:float=1e-6
    solver_tol:float=1e-8
    mip_rel_gap:float=1e-8
    horizon:int=24


def load_inputs(input_file:Path, core_file:Path):
    rows=read_xlsx_rows(input_file,'Solar_8760_2025')
    records=[(r+[None]*10)[:10] for r in rows[1:]]
    if len(records)!=8760: raise ValueError(f'Expected 8760 rows, got {len(records)}')
    a=np.array([[r[i] for i in (0,1,3,4,5,6,8,9)] for r in records],float)
    if not np.isfinite(a).all():raise ValueError('Missing or non-finite hourly input')
    if np.max(np.abs(np.diff(a[:,0])*24-1))>1e-6:raise ValueError('Timestamps are not continuous hourly records')
    if not np.array_equal(a[:,4],np.tile(np.arange(1,25),365)):raise ValueError('Hour labels must repeat 1..24')
    if np.any(a[:,5:7]<0):raise ValueError('Negative irradiation or base load')
    vals={str(r[0]).strip().lower():r[1] for r in read_xlsx_rows(core_file) if len(r)>1 and r[0] is not None}
    cfg=Settings(pv_area=float(vals.get('pv area',50)),eta_ch=float(vals.get('battery efficiency',.92)),eta_dis=float(vals.get('battery efficiency',.92)))
    prices=a[:,7]/1000
    inp={'rows':records,'monthly_input':read_xlsx_rows(input_file,'Monthly_Profile'),
         'ts':a[:,0],'date':a[:,1],'month':a[:,2].astype(int),'day':a[:,3].astype(int),'hour':a[:,4].astype(int),
         'irr':a[:,5],'load':a[:,6],'price':prices,'pv':a[:,5]*cfg.pv_area*cfg.pv_efficiency,
         'daily_mean':np.repeat(prices.reshape(365,24).mean(1),24),
         'daily_min':np.repeat(prices.reshape(365,24).min(1),24),
         'daily_max':np.repeat(prices.reshape(365,24).max(1),24),
         'input_file':str(input_file),'core_file':str(core_file),
         'input_sha256':hashlib.sha256(input_file.read_bytes()).hexdigest(),
         'core_sha256':hashlib.sha256(core_file.read_bytes()).hexdigest()}
    return inp,cfg


def omega_profile(inp,alpha,legacy=False):
    if legacy:
        h=inp['hour']
        return np.where((h<=6)|(h==24),.55,np.where(h<=10,1,np.where(h<=16,.8,np.where(h<=22,1.35,.65))))
    return inp['daily_mean']+alpha*inp['load']


def dispatch_ab(inp,cfg,alpha,battery,strategy,legacy=False,legacy_omega=False):
    n=len(inp['load']);p=inp['price'];D=inp['load'];pv=inp['pv'];hrs=inp['hour']
    om=omega_profile(inp,alpha,legacy_omega)
    direct=np.maximum(0,np.minimum.reduce([D,pv,(om-p)/alpha]))
    out={k:np.zeros(n) for k in ('pv_ch','grid_ch','dis_load','dis_sell','soc_beg','soc_end','loss','low','high','reserve','simultaneous_candidate')}
    emin=battery*cfg.soc_min;emax=battery*cfg.soc_max;soc=battery*cfg.soc0
    for t in range(n):
        if legacy and t%24==0:soc=battery*cfg.soc0
        out['soc_beg'][t]=soc
        decay=soc*cfg.sigma if legacy else max(0,soc-emin)*cfg.sigma
        available=soc if legacy else soc-decay
        pv_surplus=max(0,pv[t]-direct[t]);residual=max(0,D[t]-direct[t])
        if strategy=='A':
            lo=inp['daily_min'][t]+cfg.low*(inp['daily_max'][t]-inp['daily_min'][t])
            hi=inp['daily_min'][t]+cfg.high*(inp['daily_max'][t]-inp['daily_min'][t])
            res_frac=cfg.soc_min
            ch=min(cfg.p_ch,pv_surplus,max(0,(emax-available)/cfg.eta_ch)) if pv_surplus>0 and p[t]<=lo else 0.
            dis=min(cfg.p_dis,residual,max(0,(available-emin)*cfg.eta_dis)) if residual>0 and p[t]>=hi else 0.
        else:
            future=p[t:min(t+24,n)];mn=float(future.min());mx=float(future.max())
            lo=mn+cfg.adaptive_low*(mx-mn);hi=mn+cfg.adaptive_high*(mx-mn)
            res_frac=cfg.reserve_evening if 17<=hrs[t]<=22 else cfg.reserve_base
            arb=mx*cfg.eta_ch*cfg.eta_dis > p[t]+cfg.arb_margin+cfg.psi
            if pv_surplus>0:
                potential=pv_surplus if p[t]<=lo or arb else 0.
            else:
                potential=cfg.grid_charge_limit if p[t]<=lo and arb else 0.
            ch=min(cfg.p_ch,potential,max(0,(emax-available)/cfg.eta_ch))
            dis=min(cfg.p_dis,residual+cfg.sell_limit,max(0,(available-battery*res_frac)*cfg.eta_dis)) if p[t]>=hi else 0.
        if ch>cfg.numeric_tol and dis>cfg.numeric_tol:
            out['simultaneous_candidate'][t]=1
            if not legacy:ch=0. # explicit high-price discharge priority; no simultaneous operation
        pv_ch=min(ch,pv_surplus);grid_ch=max(0,ch-pv_ch)
        dis_load=min(dis,residual);dis_sell=max(0,dis-dis_load)
        end=soc-decay+cfg.eta_ch*ch-dis/cfg.eta_dis
        if legacy:end=max(emin,min(emax,end))
        if not legacy and not(emin-1e-7<=end<=emax+1e-7):raise AssertionError(f'SOC bounds {strategy} t={t}: {end}')
        for k,v in [('pv_ch',pv_ch),('grid_ch',grid_ch),('dis_load',dis_load),('dis_sell',dis_sell),('soc_end',end),('loss',decay),('low',lo),('high',hi),('reserve',res_frac)]:out[k][t]=v
        soc=end
    out['direct']=direct;out['solve_seconds']=np.zeros(n);out['solver_mode']=np.zeros(n)
    return out


def solve_storage_window(D,pv,p,hours,cfg,battery,soc0,legacy=False):
    n=len(p);direct=np.minimum(D,pv);resid=np.maximum(D-direct,0);surplus=np.maximum(pv-direct,0)
    sell=np.minimum(p,cfg.export_factor*p+cfg.theta)
    high=p>=np.quantile(p,.7);N=5*n
    c=np.zeros(N)
    c[:n]=cfg.psi-cfg.self_reward+(0 if legacy else sell)
    c[n:2*n]=p+cfg.psi+(0 if legacy else cfg.peak_penalty*high)
    c[2*n:3*n]=-p+cfg.psi-cfg.peak_penalty*high
    c[3*n:4*n]=-sell+cfg.psi
    lower=np.zeros(N);upper=np.zeros(N)
    upper[:n]=np.minimum(cfg.p_ch,surplus)
    upper[n:2*n]=min(cfg.p_ch,cfg.grid_charge_limit)
    upper[2*n:3*n]=np.minimum(cfg.p_dis,resid)
    upper[3*n:4*n]=min(cfg.p_dis,cfg.sell_limit)
    reserve=np.where((hours>=17)&(hours<=22),cfg.reserve_evening,cfg.reserve_base)
    lower[4*n:]=battery*reserve;upper[4*n:]=battery*cfg.soc_max
    eq=np.zeros((n+1,N));rhs=np.zeros(n+1)
    for t in range(n):
        eq[t,4*n+t]=1;eq[t,t]=-cfg.eta_ch;eq[t,n+t]=-cfg.eta_ch
        eq[t,2*n+t]=1/cfg.eta_dis;eq[t,3*n+t]=1/cfg.eta_dis
        if t: eq[t,4*n+t-1]=-(1-cfg.sigma)
        rhs[t]=(soc0*(1-cfg.sigma) if t==0 else 0)+(0 if legacy else cfg.sigma*battery*cfg.soc_min)
    eq[n,5*n-1]=1
    rhs[n]=soc0 if legacy else battery*cfg.soc0
    ub=np.zeros((2*n,N));ubrhs=np.r_[np.full(n,cfg.p_ch),np.full(n,cfg.p_dis)]
    for t in range(n):
        ub[t,t]=ub[t,n+t]=1;ub[n+t,2*n+t]=ub[n+t,3*n+t]=1
    options={'primal_feasibility_tolerance':cfg.solver_tol,'dual_feasibility_tolerance':cfg.solver_tol}
    res=linprog(c,A_ub=ub,b_ub=ubrhs,A_eq=eq,b_eq=rhs,bounds=list(zip(lower,upper)),method='highs',options=options)
    if not res.success:raise RuntimeError(f'LP error: {res.message}; soc={soc0}, n={n}')
    mode=0
    totalch=res.x[:n]+res.x[n:2*n];totaldis=res.x[2*n:3*n]+res.x[3*n:4*n]
    if not legacy and np.any((totalch>cfg.qa_tol)&(totaldis>cfg.qa_tol)):
        # Exact binary-mode formulation, used only when the LP relaxation cycles.
        # LP solutions without overlap are already feasible and optimal for this MIP.
        mode=1; cm=np.r_[c,np.zeros(n)];eqm=np.c_[eq,np.zeros((n+1,n))]
        ubm=np.c_[ub,np.zeros((2*n,n))]
        rhs_m=np.r_[np.zeros(n),np.full(n,cfg.p_dis)]
        for t in range(n):ubm[t,N+t]=-cfg.p_ch;ubm[n+t,N+t]=cfg.p_dis
        res=linprog(cm,A_ub=ubm,b_ub=rhs_m,A_eq=eqm,b_eq=rhs,
                    bounds=list(zip(np.r_[lower,np.zeros(n)],np.r_[upper,np.ones(n)])),
                    integrality=np.r_[np.zeros(N,dtype=int),np.ones(n,dtype=int)],method='highs',
                    options={'mip_rel_gap':cfg.mip_rel_gap,'time_limit':60})
        if not res.success:raise RuntimeError(f'MIP error: {res.message}')
    return res.x[:N].reshape(5,n),mode


def dispatch_c(inp,cfg,battery,legacy=False,progress=False):
    n=len(inp['load']);out={k:np.zeros(n) for k in ('pv_ch','grid_ch','dis_load','dis_sell','soc_beg','soc_end','loss','low','high','reserve','simultaneous_candidate','solve_seconds','solver_mode')}
    out['direct']=np.minimum(inp['load'],inp['pv']);soc=battery*cfg.soc0
    starts=range(0,n,24) if legacy else range(n)
    for t in starts:
        end=min(t+cfg.horizon,n);start=time.perf_counter()
        sol,mode=solve_storage_window(inp['load'][t:end],inp['pv'][t:end],inp['price'][t:end],inp['hour'][t:end],cfg,battery,soc,legacy)
        elapsed=time.perf_counter()-start
        apply=end-t if legacy else 1
        for j in range(apply):
            k=t+j;out['soc_beg'][k]=soc
            for block,name in enumerate(('pv_ch','grid_ch','dis_load','dis_sell','soc_end')):out[name][k]=float(sol[block,j])
            out['loss'][k]=cfg.sigma*(soc if legacy else max(0,soc-battery*cfg.soc_min))
            soc=float(sol[4,j]);out['solve_seconds'][k]=elapsed/apply;out['solver_mode'][k]=mode
            out['reserve'][k]=cfg.reserve_evening if 17<=inp['hour'][k]<=22 else cfg.reserve_base
            ch=out['pv_ch'][k]+out['grid_ch'][k];dis=out['dis_load'][k]+out['dis_sell'][k]
            out['simultaneous_candidate'][k]=float(ch>cfg.qa_tol and dis>cfg.qa_tol)
        if progress and (t%2000==0 or t==n-1):print(f'C {battery:g} kWh: {t+1}/{n} windows',flush=True)
    out['low']=inp['daily_min']+cfg.low*(inp['daily_max']-inp['daily_min'])
    out['high']=inp['daily_min']+cfg.high*(inp['daily_max']-inp['daily_min'])
    return out


HEADERS = [
'Timestamp','Date','Month','Month_Number','Day','Hour',
'Solar availability (kW/m2)','PV generation (kWh)','Base load Demand (kWh)','Spot price (EUR/MWh)',
'omega_t (EUR/kWh)','Spot price (EUR/kWh)','Daily minimum spot (EUR/kWh)','Daily maximum spot (EUR/kWh)',
'Charge threshold display (EUR/kWh)','Discharge threshold display (EUR/kWh)','Daily maximum PV (kWh)','Decision',
'E_self EQ1 (kWh)','E_charge (kWh)','E_discharge (kWh)','SOC_begin (kWh)','SOC_end EQ9/12 (kWh)',
'E_grid_to_load EQ2-EQ4 (kWh)','Elasticity EQ6 proxy (-)','U_cons EQ7 (EUR)','E_actual EQ22 (kWh)','DeltaE (kWh)',
'D_shift (EUR)','E_bat net EQ11 (kWh)','C_deg EQ10 (EUR)','E_sell (kWh)','E_buy total (kWh)',
'W_spot (EUR)','Utility EQ8/29 (EUR)','Daily Utility EQ8/29 (EUR)','SDR capped proxy (-)',
'Charge-weighted reference (EUR/kWh)','Price_P2P EQ13 (EUR/kWh)','E_inj EQ16 (kWh)',
'U_prosumer EQ14 reported (EUR)','a1 EQ18 (-)','Load ratio (-)','gamma EQ18 (EUR/kWh)','tau EQ17 (EUR/kWh)',
'Green benefit (EUR)','SW_total EQ15 reported (EUR)','U_buyer EQ19 (EUR)','A EQ21 (EUR)',
'Price_eq EQ20 diagnostic (EUR/kWh)','CS EQ23 (EUR)','PS EQ24 (EUR)','LC EQ26 (EUR)','QC EQ27 (EUR)',
'SW_P2P EQ25 reported (EUR)','CS_pros EQ28 reported (EUR)','EQ30 not calculated','Daily price peak (EUR/kWh)',
'GS_grid EQ31 proxy (EUR)','SW_grid EQ32 reported (EUR)',
'P2P revenues (EUR)','PS_to_grid arithmetic AU-BG (EUR)','Reference daily price (EUR/kWh)',
'PV_to_battery (kWh)','Grid_to_battery (kWh)','Battery_to_load (kWh)','Battery_to_export (kWh)',
'Usable-energy self-discharge (kWh)','SOC balance residual (kWh)','Site balance residual (kWh)',
'Grid import cost (EUR)','U_P2P net of grid cost (EUR)','Delta price spot-P2P (EUR/kWh)',
'Delta utility AI-AO reported (EUR)','Delta utility AI-BT net (EUR)','SOC_fraction (-)',
'Battery throughput (kWh)','Alpha (EUR/kWh2)','Calibration residual (EUR/kWh)',
'P2P denominator diagnostic','Active P2P (0/1)','Elasticity defined (0/1)',
'Simultaneous charge-discharge (0/1)','SOC bound violation (kWh)','Terminal inventory change (kWh)',
'Solver seconds for window (s)','Mixed-integer fallback (0/1)','Export-price proxy C (EUR/kWh)',
'No-storage import (kWh)','No-storage export (kWh)','No-storage operating cost (EUR)',
'Operating cost incl degradation (EUR)','Battery operating saving vs no storage (EUR)',
'Battery loss (kWh)','Buyer marginal utility at injection (EUR/kWh)'
]


def evaluate(inp,cfg,alpha,battery,strategy,dispatch,legacy=False,legacy_omega=False):
    n=len(inp['load']);p=inp['price'];D=inp['load'];pv=inp['pv'];o=omega_profile(inp,alpha,legacy_omega)
    s=dispatch['direct'];pc=dispatch['pv_ch'];gc=dispatch['grid_ch'];dl=dispatch['dis_load'];de=dispatch['dis_sell']
    ch=pc+gc;dis=dl+de;sb=dispatch['soc_beg'];se=dispatch['soc_end']
    grid=np.maximum(0,D-s-dl);buy=grid+gc;sell=np.maximum(0,pv-s-pc+de)
    actual=s+dl+(buy if legacy else grid);dE=D-actual
    consumption=o*actual-alpha/2*actual**2;shift=cfg.zeta/2*dE**2
    deg=cfg.psi*(np.abs(ch-dis) if legacy else ch+dis)
    spotcash=p*(sell-buy);uconv=consumption-shift+spotcash-deg
    inj=sell.copy();sdr=np.minimum(1,np.divide(inj,D,out=np.zeros(n),where=D>0));sdr[inj<=cfg.numeric_tol]=0
    wsum=(ch*p).reshape(-1,24).sum(1);csum=ch.reshape(-1,24).sum(1)
    cp=np.repeat(np.divide(wsum,csum,out=np.zeros_like(wsum),where=csum>cfg.numeric_tol),24);cp[inj<=cfg.numeric_tol]=0
    denom=(p-cp)*sdr+cp
    pp=p.copy();valid=(sdr!=0)&(np.abs(cp)>cfg.numeric_tol)&(np.abs(denom)>cfg.numeric_tol)
    pp[valid]=p[valid]*cp[valid]/denom[valid]
    upros=consumption-shift+inj*pp-deg
    dmin=np.repeat(D.reshape(-1,24).min(1),24);dmax=np.repeat(D.reshape(-1,24).max(1),24)
    lratio=np.divide(D,dmax,out=np.zeros(n),where=dmax!=0)
    a1=cfg.a1_min+(cfg.a1_max-cfg.a1_min)*np.divide(D-dmin,dmax-dmin,out=np.zeros(n),where=(dmax-dmin)!=0)
    gam=cfg.tau_base*a1;tau=cfg.tau_base+gam*lratio**2
    green=cfg.theta*cfg.rho*inj;sw=consumption-shift-deg+green-tau*inj
    ub=o*inj-alpha/2*inj**2-pp*inj+green
    a=o*inj-alpha/2*inj**2+green-consumption+shift+deg
    eq=np.full(n,np.nan);active=inj>cfg.numeric_tol;eq[active]=a[active]/(2*inj[active])
    cs=ub.copy();ps=inj*(pp-cfg.b_i-cfg.psi-cfg.zeta*np.abs(dE))-cfg.a_i/2*inj**2
    lc=(o+cfg.theta*cfg.rho-cfg.b_i-cfg.psi-cfg.zeta*np.abs(dE))*inj;qc=(alpha+cfg.a_i)/2*inj**2
    p2psw=lc-qc;csgrid=grid*(o-alpha*pv-p)-alpha/2*grid**2
    gs=np.maximum(0,(inp['daily_max']-p)*dl)
    elasticity=np.divide(-p/alpha,grid,out=np.zeros(n),where=grid>cfg.numeric_tol)
    site=pv+buy+dis-actual-ch-sell
    socres=se-(sb-dispatch['loss']+cfg.eta_ch*ch-dis/cfg.eta_dis)
    continuity=sb[1:]-se[:-1]
    bounds=np.maximum.reduce([np.zeros(n),battery*cfg.soc_min-se,se-battery*cfg.soc_max])
    noimp=np.maximum(D-pv,0);noexp=np.maximum(pv-D,0);nocost=p*(noimp-noexp)
    netcost=p*(buy-sell)+deg
    cols={
        'K':o,'L':p,'M':inp['daily_min'],'N':inp['daily_max'],
        'O':inp['daily_min']+cfg.low*(inp['daily_max']-inp['daily_min']),
        'P':inp['daily_min']+cfg.high*(inp['daily_max']-inp['daily_min']),
        'Q':np.repeat(pv.reshape(-1,24).max(1),24),'S':s,'T':ch,'U':dis,'V':sb,'W':se,'X':grid,'Y':elasticity,'Z':consumption,
        'AA':actual,'AB':dE,'AC':shift,'AD':ch-dis,'AE':deg,'AF':sell,'AG':buy,'AH':spotcash,'AI':uconv,
        'AJ':np.repeat(uconv.reshape(-1,24).sum(1),24),'AK':sdr,'AL':cp,'AM':pp,'AN':inj,'AO':upros,
        'AP':a1,'AQ':lratio,'AR':gam,'AS':tau,'AT':green,'AU':sw,'AV':ub,'AW':a,'AX':eq,'AY':cs,'AZ':ps,
        'BA':lc,'BB':qc,'BC':p2psw,'BD':csgrid,'BF':inp['daily_max'],'BG':gs,'BH':csgrid+gs,
        'BI':inj*pp,'BJ':sw-gs,'BK':inp['daily_mean'],'BL':pc,'BM':gc,'BN':dl,'BO':de,'BP':dispatch['loss'],
        'BQ':socres,'BR':site,'BS':p*buy,'BT':upros-p*buy,'BU':p-pp,'BV':uconv-upros,'BW':uconv-(upros-p*buy),
        'BX':se/battery,'BY':ch+dis,'BZ':np.full(n,alpha),'CA':o-inp['daily_mean']-alpha*D,
        'CB':denom,'CC':active.astype(float),'CD':(grid>cfg.numeric_tol).astype(float),
        'CE':((ch>cfg.qa_tol)&(dis>cfg.qa_tol)).astype(float),'CF':bounds,'CG':np.full(n,se[-1]-battery*cfg.soc0),
        'CH':dispatch['solve_seconds'],'CI':dispatch['solver_mode'],'CJ':np.minimum(p,cfg.export_factor*p+cfg.theta),
        'CK':noimp,'CL':noexp,'CM':nocost,'CN':netcost,'CO':nocost-netcost,
        'CP':(1-cfg.eta_ch)*ch+(1/cfg.eta_dis-1)*dis+dispatch['loss'],'CQ':o+cfg.theta*cfg.rho-alpha*inj
    }
    qa={'calibration_max_abs':float(np.max(np.abs(cols['CA']))),
        'soc_balance_max_abs':float(np.max(np.abs(socres))),
        'site_balance_max_abs':float(np.max(np.abs(site))),
        'soc_continuity_max_abs':float(np.max(np.abs(continuity))),
        'soc_bound_max_violation':float(np.max(bounds)),
        'charge_power_violation':float(max(0,np.max(ch)-cfg.p_ch)),
        'discharge_power_violation':float(max(0,np.max(dis)-cfg.p_dis)),
        'simultaneous_hours':int(cols['CE'].sum()),
        'calculation_nonfinite':int(sum(np.count_nonzero(~np.isfinite(v)) for k,v in cols.items() if k!='AX')),
        'p2p_singular_fallback_hours':int(np.sum((sdr!=0)&(np.abs(cp)>cfg.numeric_tol)&(np.abs(denom)<=cfg.numeric_tol))),
        'negative_p2p_prices':int(np.sum(pp<0)),
        'negative_buyer_utility_active':int(np.sum((ub<0)&active)),
        'negative_buyer_marginal_active':int(np.sum((cols['CQ']<0)&active)),
        'active_p2p_hours':int(active.sum()),
        'grid_near_zero_hours':int((~(grid>cfg.numeric_tol)).sum()),
        'solver_windows':int(np.count_nonzero(dispatch['solve_seconds'])),
        'mip_fallback_windows':int(np.sum(dispatch['solver_mode'])),
        'solver_seconds_total':float(np.sum(dispatch['solve_seconds'])),
        'end_soc_minus_start_kwh':float(se[-1]-battery*cfg.soc0),
        'cs_ps_identity_max_abs':float(np.max(np.abs(cs+ps-p2psw))),
        'equal_utility_identity_max_abs':float(np.max(np.abs((ub-upros)[active]-2*inj[active]*(eq[active]-pp[active])))) if np.any(active) else 0.}
    numeric_checks=['calibration_max_abs','soc_balance_max_abs','site_balance_max_abs','soc_continuity_max_abs','soc_bound_max_violation','charge_power_violation','discharge_power_violation','cs_ps_identity_max_abs','equal_utility_identity_max_abs']
    qa['technical_pass']=not legacy and all(qa[k]<=cfg.qa_tol for k in numeric_checks) and qa['simultaneous_hours']==0 and qa['calculation_nonfinite']==0
    return cols,qa


def compute_case(inp,cfg,alpha,battery,strategy,cached_c=None,legacy=False,legacy_omega=False):
    start=time.perf_counter()
    if strategy=='C':dispatch=cached_c if cached_c is not None else dispatch_c(inp,cfg,battery,legacy)
    else:dispatch=dispatch_ab(inp,cfg,alpha,battery,strategy,legacy,legacy_omega)
    cols,qa=evaluate(inp,cfg,alpha,battery,strategy,dispatch,legacy,legacy_omega)
    qa['evaluation_seconds']=time.perf_counter()-start
    return cols,qa


"""Shared workbook layout and formula definitions (no spreadsheet I/O)."""
import calendar
import numpy as np

SUM_COLS=['H','I','S','T','U','X','AF','AG','AI','AO','AU','AV','AY','AZ','BC','BD','BG','BH','BI','BJ','BT','CN','CO','CP']
PARAM_MAP={'alpha':3,'zeta':4,'psi':5,'battery':6,'p_ch':7,'p_dis':8,'eta_ch':9,'eta_dis':10,'soc0':11,'soc_min':12,'soc_max':13,
           'tau_base':15,'theta':16,'rho':17,'b_i':18,'a_i':19,'a1_min':20,'a1_max':21,'low':22,'high':23,
           'grid_charge_limit':32,'sell_limit':33,'peak_penalty':34,'self_reward':35,'reserve_base':37,'reserve_evening':38,
           'adaptive_low':39,'adaptive_high':40,'arb_margin':41,'sigma':42,'numeric_tol':43,'pv_efficiency':44,'pv_area':45,
           'solver_tol':46,'mip_rel_gap':47,'qa_tol':48,'export_factor':49,'horizon':50}

NOTES=[
('Purpose','36 deterministic cases: alpha 0.20/0.25/0.30 x A/B/C x 10/15/20/30 kWh. Same supplied 2025 inputs.'),
('Calibration','omega_t = arithmetic mean of the 24 input spot prices in the calendar day (EUR/kWh) + alpha x Base load Demand_t. No fixed numerical price is imposed.'),
('Reference profile','Base load Demand is the exogenous calibration quantity. The original banded omega profile is replaced. The alpha=0.25 case is therefore a NEW calibrated baseline.'),
('Version and comparison','v4 corrects physical dispatch/accounting and changes calibration. Compare the alpha cases within this v4 baseline; do not attribute old-vs-new changes solely to alpha.'),
('Excel interpretation','Dispatch sheet holds Python controller/solver snapshots. Hourly evaluation and aggregations use Excel formulas. RERUN PYTHON after changing inputs or scenario parameters; Excel alone does not re-optimize dispatch.'),
('Strategy A','Calendar-day min/max thresholds (shares 1/3 and 2/3); PV-only charging; discharge to load. Continuous SOC, no daily reset. Discharge takes precedence if charge and discharge rules overlap.'),
('Strategy B','24-hour look-ahead price min/max thresholds (shares 0.30/0.70); PV/grid charging; battery export; 30% evening discharge reserve, 10% otherwise. Continuous SOC and no simultaneous charge/discharge.'),
('Strategy C','Re-optimizes at every hour over the next min(24, remaining) records; applies only the first decision. Cost/proxy-incentive objective, not maximization of the reported utility/welfare indicators.'),
('C objective corrections','PV charging includes forgone proxy export revenue. Peak proxy penalty applies to grid charging too. Discharge/charge complementarity is enforced; LP solutions are accepted only when complementarity holds, otherwise binary-mode HiGHS MIP is solved.'),
('C alpha interpretation','Base load is fixed and direct PV consumption equals min(load, PV). Neither alpha nor omega enters C dispatch. Dispatch is reused across alpha cases; only ex-post utility/welfare valuation changes.'),
('Forecast assumption','B/C use the supplied look-ahead trajectory as perfect information within the window. There is no forecast-error model. A also uses full calendar-day price extrema.'),
('Self-discharge convention','Hourly self-discharge acts on usable energy above the minimum non-dispatchable reserve. This explicitly avoids silently creating energy by clamping an under-minimum SOC.'),
('Physical accounting','Grid-to-load and grid-to-battery are separated. E_actual excludes grid charging. Base household demand remains served; this is not a newly implemented endogenous load-curtailment model.'),
('Degradation','Cost = psi x (charge + discharge), AC-side throughput. No capacity fade is simulated. Both charging and discharging incur cost; the original absolute-net formula is not used.'),
('Initial and terminal energy','All start at 90%. C has 90% end-of-window target and 90% year-end SOC. A/B have no forced year-end target. Final-minus-initial inventory is reported; policy comparisons are not pure controller-intelligence tests.'),
('Reported EQ14 and net utility','AO retains the original EQ14 expression, which omits grid-purchase cost. BT provides AO minus grid cost. Do not label AO a complete net P2P profit.'),
('Reported welfare formulas','AU, AY/AZ/BC, BD/BG/BH retain the source algebra as diagnostic indicators. Economic definitions, proxy costs and common utility calibration require review before journal interpretation. Technical QA is NOT economic/field validation.'),
('PS_to_grid arithmetic','BJ = AU - BG is preserved as the requested arithmetic indicator. AU contains P2P injection/premium/network terms; this subtraction alone does not prove a pure pre-P2P welfare decomposition.'),
('P2P transaction scope','All available exports are used as a P2P injection proxy in ex-post evaluation; grid-sale and P2P-sale amounts are alternative valuations, not additive simultaneous sales.'),
('P2P participation limitation','No buyer demand cap, outside option or individual-rationality constraint is enforced. Negative buyer utility/marginal utility is retained and counted, not clipped or hidden.'),
('P2P price numerical rule','Source hyperbolic SDR formula retained, with SDR capped at one. Zero/near-zero denominator falls back to spot price and is counted; negative prices are retained. It is not a validated double-auction clearing rule.'),
('Utility-indifference price','AX equals AW/(2*injection) when injection exceeds tolerance, otherwise blank. AX is diagnostic, not the dispatch or implemented transaction price. No feasible-price bounds are silently imposed.'),
('Elasticity limitation','Y is the original -price/(alpha x grid-to-load) proxy, reported as zero at zero/near-zero import. It is NOT a newly estimated causal elasticity of optimized net imports. CD marks where this proxy is defined.'),
('Numerical verification','Calibration, balance, SOC continuity/bounds, power, complementarity and two algebraic utility identities are tested. Warnings on economic interpretation remain even when technical checks pass.'),
('Source input year','Input timestamps form a continuous 2025 calendar. Prices are used as supplied by the user; their historical provenance is not independently re-downloaded here.'),
('Downstream studies','Literature benchmarking, external pilot validation, new price years, independent omega sensitivity and degradation sensitivity are NOT part of these 36 cases.'),
('Solver documentation','https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html'),
('Source code','build_EQ1_EQ32_MultiStrategy_STANDALONE_v3_COLAB_FIXED(1).py; original retained in code package. No original files overwritten.')
]

def parameters(alpha,bat,st,cfg,inp):
    rows=[[None]*6 for _ in range(55)]
    rows[0]=[f'Alpha {alpha:.2f} | Strategy {st} | Battery {bat:g} kWh',None,None,None,None,None]
    rows[1]=['Parameter','Symbol','Value','Unit','Scope','Notes']
    names={'alpha':('Utility curvature','EUR/kWh2'),'battery':('Battery capacity','kWh'),
      'zeta':('Discomfort coefficient','EUR/kWh2'),'psi':('Degradation coefficient','EUR/kWh'),
      'p_ch':('Maximum charging power','kW'),'p_dis':('Maximum discharging power','kW'),
      'eta_ch':('Charging efficiency','fraction'),'eta_dis':('Discharging efficiency','fraction'),
      'soc0':('Initial/target SOC','fraction'),'soc_min':('Minimum SOC','fraction'),'soc_max':('Maximum SOC','fraction'),
      'pv_efficiency':('PV conversion efficiency','fraction'),'pv_area':('PV area','m2'),'numeric_tol':('Zero guard','kWh / price divisor'),
      'solver_tol':('LP feasibility tolerance','absolute'),'mip_rel_gap':('MIP relative objective gap','fraction'),
      'qa_tol':('Numerical QA tolerance','absolute'),'horizon':('C look-ahead horizon','hours')}
    for k,r in PARAM_MAP.items():
        val=alpha if k=='alpha' else bat if k=='battery' else getattr(cfg,k)
        label,unit=names.get(k,(k.replace('_',' '),'see source code'))
        rows[r-1]=[label,k,val,unit,'All cases unless strategy-specific','Fixed within this run; rerun Python after changing']
    rows[13]=['SDR denominator','SDR demand proxy','Base load Demand','kWh','P2P ex-post','Not a separate measured buyer demand']
    rows[24]=['Model version',None,'v4_alpha_calibration_physical',None,None,None]
    rows[25]=['Input dataset',None,inp['input_file'].split('/')[-1],None,None,None]
    rows[26]=['Core assumptions',None,inp['core_file'].split('/')[-1],None,None,None]
    rows[28]=['Dispatch strategy',None,st,None,None,None]
    rows[30]=['Strategy-specific settings',None,None,None,None,None]
    rows[35]=['Terminal constraint',None,'C: 90% each rolling window; A/B: no terminal target',None,None,None]
    rows[51]=['Input SHA256',None,inp['input_sha256'],None,None,None]
    rows[52]=['Core SHA256',None,inp['core_sha256'],None,None,None]
    rows[53]=['Calendar',None,'2025 | 365 days | 8760 one-hour slots',None,None,None]
    rows[54]=['Review status',None,'Technical/algebraic QA; economic limitations in Model_Notes',None,None,None]
    return rows


def dispatch_matrix(inp,vals,qa,dispatch):
    return np.column_stack([dispatch[k] for k in ['direct','pv_ch','grid_ch','dis_load','dis_sell','soc_beg','soc_end','loss','solve_seconds','solver_mode','low','high','reserve','simultaneous_candidate']]).tolist()
DISPATCH_HEADERS=['Direct PV self-use (kWh)','PV charge (kWh)','Grid charge (kWh)','Discharge to load (kWh)','Discharge to export (kWh)',
'SOC start (kWh)','SOC end (kWh)','Self-discharge (kWh)','Solver seconds (s)','MIP fallback (0/1)',
'Lower threshold (EUR/kWh)','Upper threshold (EUR/kWh)','Reserve fraction (-)','Overlapping rule candidates (0/1)']


def hourly_formula_row(r:int,n:int=8760):
    ds=2+((r-2)//24)*24;de=ds+23;end=n+1;p='Parameters!$C$';h='Solar_8760_2025'
    f={
    'K':f'=BK{r}+{p}3*I{r}','L':f'=J{r}/1000','M':f'=MIN($L${ds}:$L${de})','N':f'=MAX($L${ds}:$L${de})',
    'O':f'=Dispatch!K{r}','P':f'=Dispatch!L{r}','Q':f'=MAX($H${ds}:$H${de})',
    'R':f'=IF(BM{r}>{p}43,"Grid charge",IF(BO{r}>{p}43,"Battery sell",IF(U{r}>{p}43,"Discharge",IF(T{r}>{p}43,"Charge",IF(AF{r}>{p}43,"Sell",IF(S{r}>{p}43,"Self consume","Buy from grid"))))))',
    'S':f'=Dispatch!A{r}','T':f'=BL{r}+BM{r}','U':f'=BN{r}+BO{r}','V':f'=Dispatch!F{r}','W':f'=Dispatch!G{r}',
    'X':f'=MAX(0,I{r}-S{r}-BN{r})','Y':f'=IF(X{r}<={p}43,0,-L{r}/({p}3*X{r}))',
    'Z':f'=K{r}*AA{r}-{p}3/2*AA{r}^2','AA':f'=S{r}+BN{r}+X{r}','AB':f'=I{r}-AA{r}',
    'AC':f'={p}4/2*AB{r}^2','AD':f'=T{r}-U{r}','AE':f'={p}5*BY{r}',
    'AF':f'=MAX(0,H{r}-S{r}-BL{r}+BO{r})','AG':f'=X{r}+BM{r}','AH':f'=L{r}*(AF{r}-AG{r})',
    'AI':f'=Z{r}-AC{r}+AH{r}-AE{r}','AJ':f'=SUM($AI${ds}:$AI${de})',
    'AK':f'=IF(OR(I{r}<=0,AN{r}<={p}43),0,MIN(1,AN{r}/I{r}))',
    'AL':f'=IF(OR(AN{r}<={p}43,SUM($T${ds}:$T${de})<={p}43),0,SUMPRODUCT($T${ds}:$T${de},$L${ds}:$L${de})/SUM($T${ds}:$T${de}))',
    'AM':f'=IF(OR(AK{r}=0,ABS(AL{r})<={p}43,ABS(CB{r})<={p}43),L{r},L{r}*AL{r}/CB{r})',
    'AN':f'=AF{r}','AO':f'=Z{r}-AC{r}+AN{r}*AM{r}-AE{r}',
    'AP':f'={p}20+({p}21-{p}20)*IF(MAX($I${ds}:$I${de})=MIN($I${ds}:$I${de}),0,(I{r}-MIN($I${ds}:$I${de}))/(MAX($I${ds}:$I${de})-MIN($I${ds}:$I${de})))',
    'AQ':f'=IF(MAX($I${ds}:$I${de})=0,0,I{r}/MAX($I${ds}:$I${de}))','AR':f'={p}15*AP{r}',
    'AS':f'={p}15+AR{r}*AQ{r}^2','AT':f'={p}16*{p}17*AN{r}','AU':f'=Z{r}-AC{r}-AE{r}+AT{r}-AS{r}*AN{r}',
    'AV':f'=K{r}*AN{r}-{p}3/2*AN{r}^2-AM{r}*AN{r}+AT{r}',
    'AW':f'=K{r}*AN{r}-{p}3/2*AN{r}^2+AT{r}-Z{r}+AC{r}+AE{r}',
    'AX':f'=IF(AN{r}<={p}43,"",AW{r}/(2*AN{r}))','AY':f'=AV{r}',
    'AZ':f'=AN{r}*(AM{r}-{p}18-{p}5-{p}4*ABS(AB{r}))-{p}19/2*AN{r}^2',
    'BA':f'=(K{r}+{p}16*{p}17-{p}18-{p}5-{p}4*ABS(AB{r}))*AN{r}',
    'BB':f'=({p}3+{p}19)/2*AN{r}^2','BC':f'=BA{r}-BB{r}',
    'BD':f'=X{r}*(K{r}-{p}3*H{r}-L{r})-{p}3/2*X{r}^2','BE':'=""',
    'BF':f'=N{r}','BG':f'=MAX(0,(BF{r}-L{r})*BN{r})','BH':f'=BD{r}+BG{r}',
    'BI':f'=AN{r}*AM{r}','BJ':f'=AU{r}-BG{r}','BK':f'=AVERAGE($L${ds}:$L${de})',
    'BL':f'=Dispatch!B{r}','BM':f'=Dispatch!C{r}','BN':f'=Dispatch!D{r}','BO':f'=Dispatch!E{r}',
    'BP':f'={p}42*MAX(0,V{r}-{p}6*{p}12)',
    'BQ':f'=W{r}-(V{r}-BP{r}+{p}9*T{r}-U{r}/{p}10)',
    'BR':f'=H{r}+AG{r}+U{r}-AA{r}-T{r}-AF{r}',
    'BS':f'=L{r}*AG{r}','BT':f'=AO{r}-BS{r}','BU':f'=L{r}-AM{r}',
    'BV':f'=AI{r}-AO{r}','BW':f'=AI{r}-BT{r}','BX':f'=W{r}/{p}6','BY':f'=T{r}+U{r}',
    'BZ':f'={p}3','CA':f'=K{r}-BK{r}-{p}3*I{r}',
    'CB':f'=(L{r}-AL{r})*AK{r}+AL{r}','CC':f'=IF(AN{r}>{p}43,1,0)',
    'CD':f'=IF(X{r}>{p}43,1,0)','CE':f'=IF(AND(T{r}>{p}48,U{r}>{p}48),1,0)',
    'CF':f'=MAX(0,{p}6*{p}12-W{r},W{r}-{p}6*{p}13)',
    'CG':f'=$W${end}-{p}6*{p}11','CH':f'=Dispatch!I{r}','CI':f'=Dispatch!J{r}',
    'CJ':f'=MIN(L{r},{p}49*L{r}+{p}16)','CK':f'=MAX(0,I{r}-H{r})',
    'CL':f'=MAX(0,H{r}-I{r})','CM':f'=L{r}*(CK{r}-CL{r})',
    'CN':f'=L{r}*(AG{r}-AF{r})+AE{r}','CO':f'=CM{r}-CN{r}',
    'CP':f'=(1-{p}9)*T{r}+(1/{p}10-1)*U{r}+BP{r}',
    'CQ':f'=K{r}+{p}16*{p}17-{p}3*AN{r}'
    }
    return [f[colname(k)] for k in range(11,96)]


def aggregation_header(period):
    names=[HEADERS[next(i for i in range(len(HEADERS)) if colname(i+1)==c)] for c in SUM_COLS]
    return [period]+names+['Mean spot (EUR/kWh)','Mean P2P (all hours, EUR/kWh)','Mean omega (EUR/kWh)','Median active Price_eq (EUR/kWh)','Closing SOC (kWh)','Mean elasticity proxy including zeros (-)']


def aggregation_rows(inp,kind):
    rows=[];sh="'Solar_8760_2025'!"
    groups=[np.arange(d*24,(d+1)*24) for d in range(365)] if kind=='Daily' else [np.flatnonzero(inp['month']==m) for m in range(1,13)]
    for i,ix in enumerate(groups):
        a=int(ix[0])+2;b=int(ix[-1])+2
        label=float(inp['date'][ix[0]]) if kind=='Daily' else calendar.month_name[i+1]
        formulas=[f'=SUM({sh}{c}{a}:{c}{b})' for c in SUM_COLS]
        formulas += [f'=AVERAGE({sh}{c}{a}:{c}{b})' for c in ('L','AM','K')]
        formulas += [f'=IF(COUNT({sh}AX{a}:AX{b})=0,"",MEDIAN({sh}AX{a}:AX{b}))',f'={sh}W{b}',f'=AVERAGE({sh}Y{a}:Y{b})']
        rows.append([label]+formulas)
    return rows


def annual_rows(inp):
    s="'Solar_8760_2025'!";out=[]
    lookup={colname(i+1):v for i,v in enumerate(HEADERS)}
    for c in SUM_COLS:out.append([lookup[c],f'=SUM({s}{c}2:{c}8761)','kWh' if '(kWh)' in lookup[c] else 'EUR'])
    out += [
    ['Minimum SOC',f'=MIN({s}W2:W8761)','kWh'],['Maximum SOC',f'=MAX({s}W2:W8761)','kWh'],
    ['Closing minus opening SOC',f'={s}W8761-Parameters!C6*Parameters!C11','kWh'],
    ['Discharge / usable capacity proxy',f'=SUM({s}U2:U8761)/(Parameters!C6*(Parameters!C13-Parameters!C12))','cycles proxy'],
    ['Active P2P hours',f'=SUM({s}CC2:CC8761)','hours'],['Undefined elasticity proxy hours',f'=8760-SUM({s}CD2:CD8761)','hours'],
    ['Mean omega',f'=AVERAGE({s}K2:K8761)','EUR/kWh'],['Minimum omega',f'=MIN({s}K2:K8761)','EUR/kWh'],['Maximum omega',f'=MAX({s}K2:K8761)','EUR/kWh'],
    ['Mean spot price',f'=AVERAGE({s}L2:L8761)','EUR/kWh'],['Solver time (unique C dispatch)',f'=SUM({s}CH2:CH8761)','seconds'],
    ['Simultaneous charging/discharging',f'=SUM({s}CE2:CE8761)','hours'],
    ['Important interpretation','Reported EQ welfare metrics retain source algebra. Read Model_Notes.',''],
    ['Operational objective','C minimizes cost plus proxy incentives; it does not maximize reported utility.',''],
    ['Scope','No price-year, independent omega, or degradation sensitivity in these files.','']]
    return out

import types
layout = types.SimpleNamespace(**{k: globals()[k] for k in ['SUM_COLS','PARAM_MAP','NOTES','parameters','dispatch_matrix','DISPATCH_HEADERS','hourly_formula_row','aggregation_header','aggregation_rows','annual_rows']})

"""Memory-bounded serialization of the styled workbook template.

Uses standard-library ZIP/XML only. All formula caches are supplied by the
independently evaluated numerical model. The layout/template was authored with
artifact_tool; streaming avoids materialising ~1 million styled cells at once.
"""
import base64,calendar,csv,hashlib,io,json,math,re,time,zipfile
from pathlib import Path
from xml.sax.saxutils import escape
import xml.etree.ElementTree as ET
import numpy as np

S='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
C='http://schemas.openxmlformats.org/drawingml/2006/chart'


def cell(addr,value,style=0,formula=None):
    sty=f' s="{style}"' if style else ''
    if formula is not None:
        f='<x:f>'+escape(formula.lstrip('='))+'</x:f>'
        if value is None or (isinstance(value,(float,np.floating)) and not math.isfinite(value)) or value=='':
            return f'<x:c r="{addr}"{sty} t="str">{f}<x:v></x:v></x:c>'
        if isinstance(value,str):return f'<x:c r="{addr}"{sty} t="str">{f}<x:v>{escape(value)}</x:v></x:c>'
        return f'<x:c r="{addr}"{sty}>{f}<x:v>{float(value):.17g}</x:v></x:c>'
    if value is None:return f'<x:c r="{addr}"{sty}/>' if sty else ''
    if isinstance(value,(bool,np.bool_)):return f'<x:c r="{addr}"{sty} t="b"><x:v>{int(value)}</x:v></x:c>'
    if isinstance(value,(int,float,np.number)):
        if not math.isfinite(float(value)):return f'<x:c r="{addr}"{sty}/>'
        return f'<x:c r="{addr}"{sty}><x:v>{float(value):.17g}</x:v></x:c>'
    return f'<x:c r="{addr}"{sty} t="inlineStr"><x:is><x:t xml:space="preserve">{escape(str(value))}</x:t></x:is></x:c>'


def template_styles(xml):
    root=ET.fromstring(xml); styles={c.attrib['r']:int(c.attrib.get('s','0')) for c in root.findall('.//s:c',NS)}
    rows={int(r.attrib['r']):r.attrib for r in root.findall('.//s:row',NS)}
    return styles,rows


def rowtext(r,cells,height=None):
    h=f' ht="{height}" customHeight="1"' if height is not None else ''
    return f'<x:row r="{r}"{h}>'+''.join(cells)+'</x:row>'


def wrap_sheet(template,rows,rows_count,cols_count,freeze=None,autofilter=False):
    txt=template.decode('utf-8')
    before,tail=txt.split('<x:sheetData>',1);_,after=tail.split('</x:sheetData>',1)
    # Order: dimension, sheetViews, sheetFormatPr, cols, sheetData, autoFilter, ...
    before=re.sub(r'<x:dimension[^>]*/>','',before)
    before=re.sub(r'<x:sheetViews>.*?</x:sheetViews>','',before,flags=re.S)
    insert=f'<x:dimension ref="A1:{colname(cols_count)}{rows_count}"/>'
    if freeze:
        x,y=freeze;top=f'{colname(x+1)}{y+1}'
        insert+=f'<x:sheetViews><x:sheetView workbookViewId="0"><x:pane xSplit="{x}" ySplit="{y}" topLeftCell="{top}" activePane="bottomRight" state="frozen"/></x:sheetView></x:sheetViews>'
    pos=before.index('>',before.index('<x:worksheet'))+1
    before=before[:pos]+insert+before[pos:]
    after=re.sub(r'<x:autoFilter[^>]*/>','',after)
    if autofilter:after=f'<x:autoFilter ref="A1:{colname(cols_count)}{rows_count}"/>'+after
    yield (before+'<x:sheetData>').encode()
    for row in rows:yield row.encode('utf-8')
    yield ('</x:sheetData>'+after).encode('utf-8')


def hourly_rows(inp,cfg,vals,styles):
    yield rowtext(1,[cell(f'{colname(k+1)}1',v,styles.get(f'{colname(k+1)}1',0)) for k,v in enumerate(HEADERS)],48)
    nums=[vals.get(colname(k)) for k in range(11,96)]
    for i,raw in enumerate(inp['rows']):
        r=i+2;ff=layout.hourly_formula_row(r);cells=[]
        for j,v in enumerate(raw,1):
            c=colname(j);f=f'=G{r}*Parameters!$C$44*Parameters!$C$45' if j==8 else None
            if j==8:v=float(inp['pv'][i])
            cells.append(cell(f'{c}{r}',v,styles.get(f'{c}2',0),f))
        for j,f in enumerate(ff,11):
            c=colname(j)
            if c=='R':
                if vals['BM'][i]>cfg.numeric_tol:v='Grid charge'
                elif vals['BO'][i]>cfg.numeric_tol:v='Battery sell'
                elif vals['U'][i]>cfg.numeric_tol:v='Discharge'
                elif vals['T'][i]>cfg.numeric_tol:v='Charge'
                elif vals['AF'][i]>cfg.numeric_tol:v='Sell'
                elif vals['S'][i]>cfg.numeric_tol:v='Self consume'
                else:v='Buy from grid'
            elif c=='BE':v=''
            else:v=float(vals[c][i])
            cells.append(cell(f'{c}{r}',v,styles.get(f'{c}2',0),f))
        yield rowtext(r,cells)


def dmatrix(vals,dispatch):
    return np.column_stack([dispatch[k] for k in ['direct','pv_ch','grid_ch','dis_load','dis_sell','soc_beg','soc_end','loss','solve_seconds','solver_mode','low','high','reserve','simultaneous_candidate']])


def raw_matrix_rows(matrix,styles,heights=None,defaultheight=None,repeat_style_row=2):
    for i,row in enumerate(matrix,1):
        cells=[]
        for j,v in enumerate(row,1):
            c=colname(j);s=styles.get(f'{c}{i}',styles.get(f'{c}{repeat_style_row}',0))
            cells.append(cell(f'{c}{i}',v,s))
        height=heights.get(i,{}).get('ht',defaultheight) if heights else defaultheight
        yield rowtext(i,cells,height)


def aggregate_values(inp,vals,kind):
    groups=[np.arange(d*24,(d+1)*24) for d in range(365)] if kind=='Daily' else [np.flatnonzero(inp['month']==m) for m in range(1,13)]
    out=[]
    for j,ix in enumerate(groups):
        name=float(inp['date'][ix[0]]) if kind=='Daily' else calendar.month_name[j+1]
        row=[name]+[float((inp['pv'] if c=='H' else inp['load'] if c=='I' else vals[c])[ix].sum()) for c in layout.SUM_COLS]
        row += [float(vals[c][ix].mean()) for c in ('L','AM','K')]
        pp=vals['AX'][ix];row += [float(np.nanmedian(pp)) if np.any(np.isfinite(pp)) else '',float(vals['W'][ix[-1]]),float(vals['Y'][ix].mean())]
        out.append(row)
    return out


def aggr_rows(inp,vals,styles,kind):
    headers=layout.aggregation_header(kind)
    yield rowtext(1,[cell(f'{colname(j+1)}1',v,styles.get(f'{colname(j+1)}1',0)) for j,v in enumerate(headers)],48)
    mat=aggregate_values(inp,vals,kind);forms=layout.aggregation_rows(inp,kind)
    for i,(row,fr) in enumerate(zip(mat,forms),2):
        yield rowtext(i,[cell(f'{colname(j+1)}{i}',v,styles.get(f'{colname(j+1)}2',0),fr[j] if j else None) for j,v in enumerate(row)],20)


def annual_values(inp,cfg,alpha,bat,vals):
    out=[float((inp['pv'] if c=='H' else inp['load'] if c=='I' else vals[c]).sum()) for c in layout.SUM_COLS]
    out += [float(vals['W'].min()),float(vals['W'].max()),float(vals['W'][-1]-bat*cfg.soc0),float(vals['U'].sum()/(bat*(cfg.soc_max-cfg.soc_min))),
            int(vals['CC'].sum()),int(len(vals['CD'])-vals['CD'].sum()),float(vals['K'].mean()),float(vals['K'].min()),float(vals['K'].max()),
            float(vals['L'].mean()),float(vals['CH'].sum()),int(vals['CE'].sum())]
    return out


def patch_summary(template,inp,cfg,alpha,bat,st,vals):
    root=ET.fromstring(template);styles,heights=template_styles(template)
    sd=root.find('s:sheetData',NS)
    # Preserve the artifact-authored layout and use cached formula values for the KPI table.
    cellmap={c.attrib['r']:c for c in sd.findall('s:row/s:c',NS)}
    replacements={'A1':cell('A1',f'ALPHA SENSITIVITY | 2025 | {st} | {bat:g} kWh | alpha {alpha:.2f}',styles.get('A1',0))}
    ar=layout.annual_rows(inp);values=annual_values(inp,cfg,alpha,bat,vals)
    for j,(label,f,unit) in enumerate(ar,7):
        if f.startswith('='):replacements[f'B{j}']=cell(f'B{j}',values[j-7],styles.get(f'B{j}',0),f)
    text=template.decode()
    for addr,xml in replacements.items():
        pattern=rf'<x:c\b(?=[^>]*\br="{addr}")[^>]*(?:/>|>.*?</x:c>)'
        text,n=re.subn(pattern,lambda _:xml,text,count=1,flags=re.S)
        if n!=1:raise ValueError(f'Summary target not unique: {addr}')
    return text.encode()


def patch_chart(content,monthly):
    ET.register_namespace('c',C)
    root=ET.fromstring(content)
    for ref in root.findall(f'.//{{{C}}}numRef'):
        f=ref.find(f'{{{C}}}f')
        if f is None or 'Monthly_Summary' not in (f.text or ''):continue
        m=re.search(r'\$([A-Z]+)\$2',f.text)
        if not m:continue
        col=0
        for cc in m.group(1):col=col*26+ord(cc)-64
        nc=ref.find(f'{{{C}}}numCache')
        if nc is not None:ref.remove(nc)
        nc=ET.SubElement(ref,f'{{{C}}}numCache');ET.SubElement(nc,f'{{{C}}}formatCode').text='0.000'
        ET.SubElement(nc,f'{{{C}}}ptCount',{'val':'12'})
        for i,row in enumerate(monthly):
            pt=ET.SubElement(nc,f'{{{C}}}pt',{'idx':str(i)});ET.SubElement(pt,f'{{{C}}}v').text=f'{float(row[col-1]):.17g}'
    return ET.tostring(root,encoding='utf-8',xml_declaration=True)


def write_xlsx(path,template_bytes,inp,cfg,alpha,bat,st,vals,qa,dispatch):
    with zipfile.ZipFile(io.BytesIO(template_bytes)) as z:
        parts={n:z.read(n) for n in z.namelist()}
    monthly=aggregate_values(inp,vals,'Monthly')
    dynamic={}
    for k in (2,4,5,6,7,8):
        key=f'xl/worksheets/sheet{k}.xml';sty,heights=template_styles(parts[key])
        if k==2:
            rows=raw_matrix_rows(layout.parameters(alpha,bat,st,cfg,inp),sty,heights);n=55;c=6;freeze=(0,2);flt=False
        elif k==4:
            rows=hourly_rows(inp,cfg,vals,sty);n=8761;c=len(HEADERS);freeze=(6,1);flt=True
        elif k==5:
            def dr():
                yield rowtext(1,[cell(f'{colname(j+1)}1',x,sty0.get(f'{colname(j+1)}1',0)) for j,x in enumerate(layout.DISPATCH_HEADERS)],48)
                for i,row in enumerate(dmatrix(vals,dispatch),2):yield rowtext(i,[cell(f'{colname(j+1)}{i}',float(x),sty0.get(f'{colname(j+1)}2',0)) for j,x in enumerate(row)])
            # Bind local styles before the lazy generator is consumed.
            sty0=sty.copy()
            rows=dr();n=8761;c=14;freeze=(0,1);flt=True
        elif k in (6,7):
            kind='Daily' if k==6 else 'Monthly';rows=aggr_rows(inp,vals,sty,kind);n=366 if k==6 else 13;c=len(layout.aggregation_header(kind));freeze=(1,1);flt=True
        else:
            mat=[['Check or warning','Value','Interpretation','Scope']]
            for check,v in qa.items():
                explanation='Warning/context (not a feasibility failure)' if any(x in check for x in ('negative','fallback','near_zero','inventory','end_soc')) else 'Technical/algebraic check; not economic or field validation'
                mat.append([check,v,explanation,'Computed from Python arrays'])
            rows=raw_matrix_rows(mat,sty,heights,defaultheight=35);n=len(mat);c=4;freeze=(0,1);flt=True
        dynamic[key]=(rows,n,c,freeze,flt)
    # Consume generators inside this function while all case variables are fixed.
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as out:
        for name,b in parts.items():
            if name in dynamic:
                rows,n,c,freeze,flt=dynamic[name]
                with out.open(name,'w',force_zip64=True) as target:
                    for chunk in wrap_sheet(b,rows,n,c,freeze,flt):target.write(chunk)
            elif name=='xl/worksheets/sheet1.xml':out.writestr(name,patch_summary(b,inp,cfg,alpha,bat,st,vals))
            elif name.endswith('.xml') and '/charts/chart' in name:out.writestr(name,patch_chart(b,monthly))
            elif name=='xl/workbook.xml':
                text=b.decode();text=re.sub(r'<x:calcPr[^>]*/>','',text)
                text=text.replace('</x:workbook>','<x:calcPr calcId="191029" calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/></x:workbook>')
                out.writestr(name,text.encode())
            else:out.writestr(name,b)
    return monthly

TEMPLATE_BASE64 = 'UEsDBBQAAAAIAGmQNl0u4dECiAEAAK4FAAAPAAAAeGwvd29ya2Jvb2sueG1svdSxbtwwDAbgVzG09yzLtGUd4gQFsnRokTYPcKAkKjZiWYakay9vXzQpfEbboYuzERyIDz9I3txd/FR8p5jGMPesOnBW0GyCHeennp2z+9Cxu9uby/FHiM86hOfi4qc5HS89G3JejmWZzEAe0yEsNF/85EL0mNMhxKcyLZHQpoEo+6kUnLelx3Fmv+a9dtNaFTN66tnj2XuML6x4bX6yPatYEY+j7dk3KTponHWy4TVYh+w3Jf4PJTg3GroP5uxpzm+WSBPmMcxpGJfEivJPzANG9JQppo1HrB7loGqlarBGCURud8/nYGk6fQmZtqB6BXUKtWsd1I2x4Npmd9BjmDCeOtnyk+Ci2aDgmpJqRauMsGgqQK52R92PacFsho2mWTW8pk46Q1o5AQrE/hocp5fT32vdXgOSGmrQlSbS0DXmHdZozsM/UXJFadEiaVtZDQIauX9OXz9uHN3VwYG4sx26qgKh3uPG3sJ5iMGNE21QakUZIBBacdliDbKGHVDl9UGW1997+xNQSwMEFAAAAAgAaZA2XVDYZLq9AwAAWDIAAA0AAAB4bC9zdHlsZXMueG1s5Vtbb5swGP0ryH3ZtCWAIZdmpVOLyjRp6sO2h0nTHgiYBMkXZJwONu2/T9wSkpY2mRIwS16wHX+Hw/GxjaMvV+8TgpUHxOOQUQvoQw0oiHrMD+nCAisRDKbg/fVVMotFitGXJUJCSQim8SyxwFKIaKaqsbdExI2HLEI0IThgnLgiHjK+UOOII9ePszCCVahpY5W4IQUZIl0Rh4hY8diKCgtc1hqV4vLRtwDUNKAUkDbzkQW0oZZ/3n3/jPwfr6rq63dVCShqA5K+jZSmaTogZOD7ynI5I6Q5EDYFNocYO6ybe5rbPT8giriLm/uPHutx9+a5xx5vB1y8vbjIgkoBq2ohYDPK5GmUXZhqIJqBpk+PZxWjrp2RxQeMbiwyAlVT7shfyoOLLaDr1b1cgoom2+U4FKzCqyKq67zo/wjAY5hxhS/mFnDKz6HQz2Pqjnk3mR4Z05gYhnEsCV4AKAvF0IQY7w5NiHF2jVwhEKdOiLFSlr+mEbIAZRStEcvOLwYtuJvqcHRwXMxw6Be8FnZdMqgZ07FZ4dXij4R/d+cYzvR0+I7jQNt+Hr8s5CM1Z9xHfD1WEGwai1HflNV179xoCOMv2cL/LVhH63l0EtTmdL5C03UxxLgsFlBlpUCvQ1a3qKGPzX+FT4LNfQ4H0GsAbhTh9H5F5og7+UKVf523OozWayHGm9ptDpbX96UAm57hxBT0c6GQ129wuKAEbczrVg3KT+5GX1FSQBUGTQL5aT8gLkIvW6U9RAXi4PAHaXJhixNBPxcKrblQ74ULy1f6/Vf0U5hgLxKndmJ5JOlaCV0GJaAMSkAZlDBkUMKQQQlTBiVMydYJKMPsgDIYE8qwd3RHYg9PtLpsd0fCkIGEJhkJQ4bZYXSmxEiGvWMk6y8PJ9Th6KeddpQ7Du0OzjYtEpdecdhPh/eJdgcbXWt6S07b7Ggf24NCi7tYOyq0Nnj98ZzRI7W1ftJuUlvvp9oy0i7zIbo+GYxlPRmYPZouTbTl9N2kryeDPYj3SXHpN4S9iMuo+GFn3ywcJeJTnGckoUQoKx5a4Lc9gdPxZGIMzIl2MzDhzXRwadqjweX4dmTfGuZIh+M/WXQQzWdJYDMSYZSzDAv8Ij8xiOaPUhRJ6HEWs0AMPUZUFgShhx4lKUKoBsgVK44iziLERTp3F9VTo6RIg6qIy/HrxXlL2e0cPmflu12E/lvlyyRZmV3fW+LnbRoZ3xp6QPz/MY26TrndSvDdSe9dtytZQrgF7jOZ8XaSbT2ZN86rm/+IXP8FUEsDBBQAAAAIAGmQNl36XAFZAwMAANoNAAATAAAAeGwvdGhlbWUvdGhlbWUxLnhtbL1X23KbMBT8FUbvDTdz84RkEsduH9Jpp8kPyCBAjRAeSY6dv+8gbgKM4zR27AdLYs/ZReewwte3+5xor4hxXNAQmFcG0BCNihjTNARbkXzzwe3NNZyLDOVIozBHIVhkUHz//Qy0fU4on8MQZEJs5rrOowzlkF8VG0T3OUkKlkPBrwqW6jGDO0zTnOiWYbh6DjEFbd4lQTmigpcLEWFP0QGy8lr8YpY//I0vCNNeIQnBDtO42D2jvQAagVwsCAuBIT9A02+u9TaKiIlgJXAlP01gHRG/WDKQpes20lha/szsGCSCiDFw6ZffLqNEwChCtJajgk3HNXyrASuoangge+CZ9iBAYbDHDIF7b836ARJVDWfjG10FywenHyBR1dAZBdwZ1n1g9wMkqhq6o4DZ8s6zlv0AicoIpi9juOv5vtvAW0xSkB8H8YHrGt5Dg+9gutJqVQIqeo33K0lwhGTf5fBvwVYFFbLKUGCqibcNSmBUNigkeM2w9ojTTEgeOEfwHUDEjwL0AWeO6bsCjlAfIW3pOgZd3Qy5NbmYfCQTTMiTeCPokUtxvCA4XmFC5ERGtaXYZAvCGsIeMGWwG/M6Vcq1TcFDYIDJXNJBMBXVmus1Tz2ck23+s4jrpjdbO4BzDkV3wXAUn2gZ5CzlqoYSd7IOz57Q0dENddgn6pB3crIQ3/ywkOCoEF0pD8FUg+Up4cxqu+URJCguC1Yn6JX1LCUOZlN3ZH12a08oMc9gjJq8xpSSqWbruvAMRVakeP5hJUEwIaTcqksUWR/bAaH9mbYr+b3m7v7LLDaMiwfIswonL7XnK1VoAsP5Ahqr3JnL0ejDPURJgiIxsdJNH7mosxy8/Fl0OSm2ArGnLN5pa7Jlf2AcAsczHQNoMeaiKYAWY9a1z/j9oluHZJPB2sl7D22Fl+OWUxEr5Qyl9+e14nW6Ostx9X7UwLWm7NabfhIvcD4Gyrmk+Efgf9RTK6s897Gp6lDlTRqtPSHPvpDRdl35dYY6bNnSY5vXMTkb/IFqVm7+AVBLAwQUAAAACABpkDZdzW9cwukAAAAHAgAALAAAAHhsL2ZlYXR1cmVQcm9wZXJ0eUJhZy9mZWF0dXJlUHJvcGVydHlCYWcueG1snZDLasMwEEV/Rcy+luNVMbYCNQ10UShddSvLI9tEL6RJUf6+JHFJ0njV3WgOOvcyzTZbw74xptm7FjZFCQyd8sPsxhYOpJ+eYSuarENf71DSIeJH9AEjHV/kmFi2xqX6hFuYiELNeVITWpkKO6vok9dUKG+513pWyFOIKIc0IZI1vCqriuuLNizaXo6wBPZyZHQM2EI3odr3PgPjD+xr13lH0Zt08+9tYPsWOjRmgSDKhl+puD7EmtAGgxYdPShv0zb/MSZgmOkT9Z/1uwwB4+sZ/abKU+IZDCvHv+smqrUy8q7VZVwxiR9QSwMEFAAAAAgAaZA2XQ0euehlAAAAcwAAABQAAAB4bC9zaGFyZWRTdHJpbmdzLnhtbAXBUQrDIAwA0KtI/mfcPsaQ2p5F2rQKJhaTDY+/95ZtcnM/Glq7JHj6AI5k70eVK8HXzscHtnWZUdXc5CYaZ4JidkdE3QtxVt9vksnt7IOzqe/jQr0H5UMLkXHDVwhv5FwFHK5/UEsDBBQAAAAIAGmQNl1Z2SBkqgcAAOwpAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1snZpvU+M4Eoe/SpdfzVYtJHEc/u1mtiAEmKqbWSDLUPeKEnYn1o0t+SQ5wNV8+Ku2TQITyZZ5laTTrfajlqWfbP3513OewRqV5lJMg9H+MAAUsUy4WE2D0iz3joK/Pv/5fPIk1Q+dIhp4zjOhT56nQWpMcTIY6DjFnOl9WaB4zrOlVDkzel+q1UAXCllSheXZIBwODwY54yKgBivrReV8rSDBJSszcyufrpCvUjMNRpMABuQYy0w3n5BzusgAcvZcfT7xxKTTIBoHkPIkQTENhgHEpTYyv6//G22bqcPDJjzchIfDHuHjJny8CR8d9giPmvBoGx71CJ804ZOPhR804QcfCz9swg8/Fn7UhB99LPy4CT/+WPho+Dpuhh9sYDPwRj0aGGxHcDXkz5lh9EPJJ1CVE432MHoN3oz/6i6Jyed0FICuam6mgTaq+mf9+fRf11ensJh/W3z558v3L//8G35COAwn8BNO4SeMhvDjPoWfwLIiZTDcD4d0Mev6kjaNn20aH2xsM4vt3GKbW2wXFtulxXb11jao+uNNt4Q+3RLutnpmsc0stnOLbW6xXVhslxbbVdhGM/ahGdctDH+p8kzmRWkwAR2jYIpLkKUpSrMPNHmWGdtLUPE1JsBFwmNmpNJQagSTIiz5MyZw/WJSKSDhumAmTkELVuhUmn24RVWKyjOWCQJbGlRQMMVypG9xysQKNfmxBL7KBLOHb9KgBiYSuDmFR1xKhZAzUepY8cJQ5n3rMNvivamMzXhuM85txgub8dJmvHpn3KlP5FOfyNLumc04sxnPbca5zXhhM17ajFdRK9VBTRWFbVQH9qlFiJJl2xFlrag99DvLSrT5z+z+d4Kbd+47HLS8mmkwbuU4rBqPfm39+jusUKBihksBn37cp79ZWerwSVSF1wJl/dk6X84cmX7cp+0YRz4YR1Xj5POu8TOmETLJEjjHnO49N0ndwiT0IHEk6yQ59iE5tnfT/EFjtoT5zaiF4di/Go40nQwkArohyMvWRfOHOGVqhS0MTahXIVxpuilGXhQjVy0SrrtBRv7VcGXqBgm9QEJXOVaKJw9GPlT3yPwm3JvfRG1MYY/iOJJ2M429mMYtN0rWxjDuURdHkm6GyIshctXlsXwBIw1rBYl6FMORqRtk4gUysffTneEZNy8wvzkahMfwaX5362CZ9CiKI9n87raD5cCL5cDeVXcPhZK6zFHRLByBwkIqEpgtVAc9KuRI203ltc6Tl63TFvcP9Tib34wmXkw9lnxX0m4mr0WfvOyVeixf6jK1jrkeS74rVTeJ16JPXraOmi1oUh63QfRY811ZOiGqBz2dEORl66PrCiJqgWgivSrhytIN4bXmk5fjPrkOrwnE6y5pmvEqiytlN5HX4k9etg6bLaoJjZCOvJB6rP2unN1IXms/edl67HJRCRqY34xHUCj5/NLG00MHuBJ283jpAPKyddfifsMTepWohyJw5exG8lIE5GXdWIbXoHCNokTdRtJDD7hSdZN46QHysk9rJJyr+jDFTZqj4TGc3u2dXbaB9ZAErszdYF6SgLysoq2a6QQakEuo+GKpTRtTD0ngStrN5CUJyMvWZX8X1bMMsapZuIgzSHClWNI84XDD9VAJruzdcF4qgbxsfXfGjEH1AnIDqdmaPtYahARtpGK0VXUz9hARrovoZBx7iQjysj/JqRkzqXXLnqgJ96qWK1XnnmjspSTIy9ZRX7ngeZnD4u+ZHaGHdHDl6Ebwkg70r62HvrLndoQeUsGVoxvBSyqQl1VZZ1LTLZJzUWq6cwT9cgL10AqujN1AXlqBvGz9db55JDWAUrPHDCFmBYtp+11JITtYD8Xgyhy/xBlqS5JdQi/pQF62DjyNDV8j0OKUylJpO1AP4eBKtNv6LomXdCAv6wZVJLjkAhPAjGnDt0VqI+uhHFyJfci8tAN5WSc3ZAJkjitmZ+ihFFwp5ne3g+57yUstkJd1fmum6BaQHqrAlcUPxEsZkJe1HM1E3QLSY+l3ZfECibyWf/KyVoTGlS6kgULx2Pqe7KyJ9aqJK48fitf6H7meJMhsjQoMzxE+lYL/t0SYbV4y22VN05ZXlVx5NcZSJB13P7309EBzrNkLnpeZYQJlqekluFpxsRq8vizhYmWH66EWXJk9JrbqsFM3mmP1/pLT7psJ2jsYVIVCU+0c7ETv5MK2kdvXLfz8Bp4wWzI6A4BG8VgDNcgFaFmqGIFlK3xUbPcEgfWQwGz3qu3v670UBnm17KGkYBnIx/9gtRzb+d+pijeii+QWz/n/UNf7sCIrG+FAWzIU1KL+A7iBRCJtXgydHKoits8/yvqlgqMndi7e3hNeSoS8rLdwLAsH+Tv5sY34JuuJa+8FmfqdDghggSJBYeq5+XeQ6t2GVKPQ3PA1KQNeHTXRdCwlc46AnUt9yz345RBVjmqFM8zq81WbX6BwSU+jT+hYzsD21/iEDk/ULb9vpGAr/Frd5RoyXJppMNw/DEDVvVp9N7Kovk0CeJTGyPz1V4osQUW/xgEspTSbH9VFJIo9kTpXJzyZBrfLw8lRzOIwxGQSjY4OguZopfI5WimXSx7juYzLHIWpz1YqzKpO1ykv9Cvd5uDm5/8DUEsDBBQAAAAIAGmQNl0yprjnogEAADYIAAAYAAAAeGwvZHJhd2luZ3MvZHJhd2luZzEueG1s7VZta9swEP4rQt8XObbTJMZ2KQ3bt63sH6jyKRboxZyUxPv3w5bdurBBl5XCWL+Yu+fk587P6QGXt73R5AzolbMVXa8SSsAK1yh7rOgpyE87eluXfYPFxR+Q9EZbX/QNVrQNoSsY86IFw/3KdWB7o6VDw4NfOTyyBvlF2aPRLE2SG+Y7BN74FiAcYoVG5nBx96D1nRWtwwhJdCZGwuk6L9kcztg3KevkCR6ysYLuUm8iPIQztjg9ZTF5bhPcc7v1n/VL09c3nNsckXetEp+RGyCGC3QVndSw5y+L4sMkiPh6fkCimoquKbHcQEXvW46BEvZ04OV7Q4H9nrCXaOqSF05K0lc0oeTH+Iwb5lfs13Blx3F4AX0gIrKKN6Nly7EnAf+Wd0F14IGTE6orqMS4iboUxRgRLIZFfc92e8g2yX4r9/s82+azCq8yj5NSCTg4cTJgQ+yDoHlQzvpWdX5mE1cPPIr64vuX+ST48qZON00rsGGUa97KLxz8xqZOs3d2dZ68q6vTD1f/I65+TGGXy83jjcjyPN3u/htXj9jwF1D/BFBLAwQUAAAACABpkDZdy7z5BE8DAAADDwAAHQAAAHhsL2RyYXdpbmdzL2NoYXJ0cy9jaGFydDEueG1s7VfZbts6EP0VVQjQ24dGsm+zVIhdOO4WIEGNpstjQZFjiTUXYUg5cr++IClZtpMGRdMNQW3AlsjhmeGcmUPp5FkjRbQENFyrUTzYT+MIFNWMq2IU13b++Dh+Nj6hGS0J2suKUIgaKZTJ6Cgura2yJDG0BEnMvq5ANVLMNUpizb7GImFIrrgqpEiGaXqYeJDYwQmiimhJxCgG9fj9ZRwlbhR1rRiwqUYFaMJ82s75te6iEtpOEIiH4Qqm3USBuq54h2ssUYwga5cbQPfHWbMNq5EBbg/Zxv0ux7MPUQEKkFiuVfTf4mP56CRxE+43GEmCiwBsVjLXIgAprcBjJZsWlPgojcW3MHdX8/HDC61sKVafLmspCa4ePtib7A2zvcne4H+32JsZi1NCS/B7t1NdK7sZb7JpkfT4ydrjkgj3p2p5m+NT5/h007Gq5dpxIHWqGYzT/dSb9CPfDKxHCDddYD4iF2ubux1uBte5Gexw8+JTXq8iqy0R956ZM+f47K9gZnidmeE1ZgyI+0/Ka+f49R8hhTRnLKx8cnx4kA4GHQVbE0fDo8PjDnlLJymxk+ZWIEOJ4KoITHNQNkigN5VcXZBmncvekoEAC9tSSpqZbnU8b4ck+azxFXLmYjLeWzXD8QnJhIquRvHTg+FB3J4x5AfOGEm4ih2c0YKzl1wIf4NFPhVtyU79J2xhx65CY58TUwZDRkzZmQkVNuyDTW7ah+VWeHZDsSOnpYPMNVvN8K47clGQTBh7aVcCfg5a9TPS7KmzY98hLk/WZ8vliGSVz1RIRCsCyUaeVC1fShv1rTGKX/kDV2zWyjtOFxcEFztiQTPJ1S2zltPFeS7W9aegse/0WqxCybXcEEVLjVOL/qC5r0y1bcZg/naGkfkyig+PDrryDmXdURbyQzOK2phJc4Oo0EzkYiKKVhWoxX74zXxuoBW3QdppgdIXtbD8fCnOc7GjfGtJWhJxgzZtuv0V2rRVb/+06b5p0wsFWKy6R5K7SlTq3pGMrpHCOVcLYH1J3UWvdltt8zz2c6dgrwDaSs/DTVfqbdskO29HUIBi/dW1s1gvAQVZ7TRjv8yBfeDmjRKtTXgMdw3bPUz89gZ5/tR9v6NB/NS3OqR/nR1/BVBLAwQUAAAACABpkDZdhQpJdUYDAAB7DQAAHQAAAHhsL2RyYXdpbmdzL2NoYXJ0cy9jaGFydDIueG1s7VdZb9s4EP4rWiFAdx8ayd7NJcQuXPdAiwR1kyavBU3SEmsewnDkyP31BQ9ZtpsGxaa7CwRrAxLFGX4znOMTdf6iVTJZcbDC6FE6OMzThGtqmNDlKG1w8fw0fTE+pwWtCOB1TShPWiW1LegorRDrIsssrbgi9tDUXLdKLgwogvbQQJkxIHdCl0pmwzw/zjxI6uAk0WWyInKUcv385jpNMjcLptGMs6kBzcEGeR5lfq0b1NLgBDjxMELzaScowTS16HAtEs0IsLjccnA3wdpdWAOMw+4Utu66Gt+gkALXyeuPp9nwLPn99c3VH+eZk7hr0FIElgHZrtXcyICkjeYeLNvWoMS7aRGu+MKNFuNnl0ZjJdefrxulCKyf/XYwORgWB5ODwZ9usVezCFNCK+43j1PTaNx2ONvWyHr8bGNxRaS76UY9ZPi9M/x+27Bu1MZwyOrUMD7OD3Ov0s/80LEeITx0jnmPnK8xdnvJGXyfnMF+cj7PhrNEc0zMIilBsIQai08+SbfO8O1/kiTSvmNh5V+nx0f5YDCMKdkRnAxPjk875J32pAQn7YNAlhIpdBkyL7hGgsLooKqEviTtJpa9JuOSI9/tYNLOTKSPeZxS5IuBtyCY88l6a/UMxuekkDq5G6VnR8OjNFIb+RvUpojQqYOzRgr2RkjpH6CcT2Us4an/hS3s6dVg8RWxVVBkxFadmtRhw97Z7L59oEDpsxuKHQStHOTcsPUMHrsj5wUppMVrXEv+a9DqXxFmnzoc+w5xcUIfLRcjUtQ+UiEQkQSyrTjpRr1RmPStMUrfcs2ByO1a+STo8pLAco8saKGEfkCKgi4v5nJTf5q3+MlsyCuUXMwN0bQyMEXw9PZUMxXbjPHF1QwS+3WUHp8cdeUdyrpLWYgPLSgYayftPaRCCzmXE1lGVqAI/fSHxcLySG6DvOMCbS4bieJiJS/mco/5NpS0IvIebto2+09w0069/c9NT42buvNjPJM8lqNydza3pgHKL4RectbX1GMIa7/Xtl/IXvaS4x3nsdTn4aGr9dg32d6pnJdcs3703cvYrDhIst7rxn6ZA7sV9oOWUSec/lzHdqeJf71DXp25/090iBf9qEX6z6jxN1BLAwQUAAAACABpkDZd45KhqB4LAAClVAAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQyLnhtbL2cbW/jNhLHvwph4IC7F4n1YPkh22wRKzZaoLuX7rZd4N4YNEXZvEiijqIdp9gPf6AcZW1rRmFkwXmTeDL/IcWfJZHDkX76eZcmZMtVIWR223OvnR7hGZORyFa3vY2Or8a9nz/+tLt5kuqxWHOuyS5NsuJmd9tba53f9PsFW/OUFtcy59kuTWKpUqqLa6lW/SJXnEalLE36nuMM+ykVWc8ELK3z0vlBkYjHdJPoL/LpFy5Wa33bc4Me6RtHJpPi5TdJhelkj6R0V/5+EpFe3/a8oEfWIop4dttzeoRtCi3Tb/v/uT/C7OXei9xrJ/df5H47+eBFPmgnD17kQTv58EU+fIe8/wNByeyeamo+KPlEVOlkcA28SvwKsMTMjM+d2yNF2Wl92yu0Kv+z/XiX5GtKnGvPId/JV62o5qtncke+kynVmqtn4jrk8dvadGG778hryOlryP6rLQRs94BtBtjmh7Z+eXQHB+nZHKQHHuQDVTTlmivwKGDN1+d0KRNIEMKCv2iy4ZD/Pez/ZyY05D5D+sNkDoafw/6fpebFkX9tRP39iPrjphH1y+i+d9p7LRKhnwnbqC3VGwV2bYqIqfnSgUP7IhiWgv1FavvRufbAcUWiz/780n/8tgY1M0RzlySE0YIXZJMlvChI8XIqXBU5ZyIWDBx6JNpc7HhEnoRei4zotSiI2mQfiOJqk5GHZ72WGaGx5oqwNc1WIls1gxrYgBrAfbkXBZNpLJUmTPI4FkzwDPziTZEIf3MNwxq8B9agBaxBp7AGl4EV2MAKEFh8pWhEtZDZm7SQEHkhQFgBDMvxQVpBIy0QVtAprOAysIY2sIZwX6obJKM5ZUI/g5QQ7XKvBUkNIVKuA3JCwmOMhp0yGl6G0ciG0Qjuyye6E+kmNS0p0xLJ5RMyDUAi5AsGjmU4gjDBZxMS+vEbCGnUKaTRZSCNbSCNmyFForDghATJF5EoQFBje1Djd4EadwpqfBlQExtQE7gvYUWnujMx+KKHyLmm2Mk0ge9OE3gugcSPFWXm1gnCmnQKa3IZWK5jQ8t4YVM/S2JYCIMMO68qjSU0rIlGapioJTYsXOfcXCtuLtybXzOhBU36mqoV1+Trv0OYGSIvJAMnC2ElqAGDeblteLnd8nIvxMuz4uUh9y+RlfcvFBSiKyRbpAIcyLDSnLJyYVZeG1Zet6y8C7GySlsYr6a5BsrKb2BFdzArMGuBkPLbkOo2a4GF65yUVd7CeEG9+Xr/hUQ8k6nIqJbwXLBZm9IsIrmSO3idVYmHtXVdwUkiaUTuyxAwx8H7Vl6Y/4P3QPjuKpcFuMqfY7rPUhNKCp5TQ5yknBYbxSOy3Dxzk8qvdbxOxypRYbyg9jXdkCUt4LRfg2iBiUIXy1AEMACkjYJzUsiNYpwwGYFNzTBt2/PpQskK1ypbYbzAwV8jebzpuxVhpaix8pC53/AMWN0mLbBwncOySlsYL6g3ai1hVO/zDyt/q1vT6AxI3SYtsHCdQ7JKWxgvMIlHwFTrFPVfwKnZyr92Ng2RS9/4DFDdJi2wcJ2DskpbGC9wvwkDhfljoJA0heMhoCZngOo2YYGF6xqUZ5WxMF7gwLtmjxxkhUvQNVQlsVtDYQ3YwMK0LWFh4TqHZZWmMF4YLHhFNMUl6CKqkpzCgs8srAErWN3mKLBwncOyylEYL6g3iXyCSb3PP6z8TzH5Jz8wNe8Mat1mK7BwnVOzylYYL6g3a7GCK2/eKwgrwSm34ckPzM0/g1u3uQssXOfcrHIXxuulNz/KmKagNaysw6PSKNB3Blrnx9Z6l60W9MYLTIzJiL9WIcLfuQA8rKNl+49428GiLPNZMJqIpSprGhb5+rkQjIJlVfdg/BlonR9b60NhtVI2XnD+Pd9oElFNCw7XXhwoD4fiaFV8Gs/U7P1z+K/rXVKAd8B7MOgMtM6PrfXjt1p8Gi9wm08qTmhRbNLcUAN3f6YH4sMhGDUNwWng5uGAGpiB1vmxtT4cVss84wWczJA1rKwnJzPkOwOt82NrvctWCx7jhez85VSz9etFFUY4AQ/taJFzcMGGKUExZqB1fmytlyNaLR2MV50SaA0r6zEl0HcGWufH1nqXrSbQxgvMUp/e8UjBtRbZCj7jDsIcHqMLHiPkOwOt82Nr/Rit5p3GCzrGlRLRvvqGk0SkcMnrtEm92KsXqDqs1DYVHlhLNlMZTNu2ePRCU1Dfrs4XneMlSRO5BlkTMv8dyM6YfWLatsguNPv0rWafxgvqTc7pI8l5RhOkKLFJuGgQhpWwlgAbwOQGZ5DrtvgXC9c5OatJuPFCzpqYKP5EFbjrOG3SLXBdWOnqiUuY2xl7a5i2LbcL7a2ZobHghqwY/uDKbFMnhMnMHJdAarYP9Ie3cGTdEN6QifMPwilbEyWTxNRxPYkskk8fyF1/ekMySXTV8r5YCMYJLixA6/zYWh8mq4WFj+1S8YKrLcc3jt8Q4pvHldAu1Ys1Y/X97nanCwvX+ffbaglk/tsEjm95dtrUK7tm7aJBG1baWlYRxnfG/hembYvvQvtfvtVy0HiBafeI5lpsTVULnAV+S7jA0sGV0BLcGfthmLYtuAvthw2sFrXGqxEcmgh+S7lAM8KV8hTdCESHtWODDtO2fY7rQrtjA6vFvfECAaglScvia5gbLlvgsrCS1SZy8I0Oa8WKWrfbZFi4zqlZpSuMFzgwYpXCRVLvVoSVosbKcZB5N9qGDa5ukxNYuM5xWSUnjBfUm/9wJclqgy2XMFm2SbkSbKGRB7wr3UnVFL+CK+WxZh6/rUmf5EowTiKxFQVcxTrD9G3RXeqpZLvHkrHC17/MYullv+mtx1OwIPl20awMK2VtYTCGUQ5alGdjorb8LpSqGFilKowXwo8qjlwrsWeTtwtME1aaY1AB/Ngr1kCKPEfebU4CC9c5IKuchPGCevPbA4k5LcRy/6IGLROuaMbghTcWpJDJliv8Qgk/q8yvkLMLaYUuC5lsNHJj67b+FwvXOTyrTInxgnrz6dcHonhCy8m/XP6Xs/KvFc1hfEiYVOQLxZMFogsrnS2/UZurY7cJEyxc5/ysEibGC+rN5/0Mgybk97u3Tj0kxP8oftphBcPmB1kJjNucet0mS7BwnaOzSpYYL6g3fJebl6XElGFPHTUrF7gyrJSn4JDT7Yx0CaZti+5C6ZLAKl1ivKDehCSR8vGKrjmNyFoq8TdSyoQFaNCEleaYnQfvfOENbBS4uz/DFG3fn3KhJElglSQxXvWiDdAaVtbRUUED6DsDrfNja73LVhkC4wUN4L6S6esvd14AFktOD4SHR/ViHZ2EC7xR7FLmDtxl7A2jiT92GI1dRilljI7G48nSW9IJZxM6mIxGzsiLHTZ2PRrTYDKkIPx7sAsz0Do/ttYHy2p9brzAE9IUfDWNlQ+OlQ+PFfMnNPIdN2b+0gti32eTyA/YkEYj7nA+jFyfO8x33ckoGDpDxx3EEefOiAVBHCyXMTxWUBdmoHV+bK2PldWC2HiBY0UTnkUUvuUciA4HagAPlOd4AflO/GFAIvpckO9kPBo6RGb8ylyASJFIDV6F7sF2ZqB1fmytj4bdi7CQtdQXvhX8iRSa6g1cDnWgPBySAB6SPzhbZ2ZC1qfJii8VFYz8fveBcCbNI8ZsX+JSVqkWRGSkLIdd1F+it6sGCixWBa3zY2s1UP2TdzmmXK14yJP9ax5fPxHFY/No0415O+JefuyZ0xX/VGaMC5LwWN/2nOtRj6j9WJd/a5mXfwU9spRay7T6ZG6UXJlPfo/EUurXD/uWXt84+vH/UEsDBBQAAAAIAGmQNl0/dxdIig8AABYyAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDMueG1snVtpc+O40f4rXaraqpk3lijLx8zI8aZkm3OkZm2v7dnZzRcXRLZExCDABUAdqfz4VAOkSFrgvEo+WWwcJPpBXw/gv/5tkwtYoTZcycvB8Wg8AJSJSrlcXg5Kuxi+H/zt579upmulX0yGaGGTC2mmm8tBZm0xjSKTZJgzM1IFyk0uFkrnzJqR0svIFBpZ6oblIpqMx+dRzrgc0IRO+tF1vteQ4oKVwj6o9Wfky8xeDo7PBhBRx0QJU/2FnNNHDiBnG/d3zVObXQ4mHwaQ8TRFeTkYDyApjVX5d9923Ezjh0+q4ZNm+Nl/MfykGn7yvw0/rYaf/m/Dz6rhZ//F8KjRoVP6DbOMHrRag3adSN+nk3rwDgGHU0J9ZscDMO6t9nJgrHYtq58f4tkNXMUf7x5i+HL7FD/cP8RPX24/wUP8+O3r0yP8G1ankKsUBTCZgklUgfQ9K/9Vu/mvdvNHO9l1QHYTkMVtWeSW1VrdiV/d+fsfre7EzXB6+mp596UulAl/cDXktUZOziFFizrnkhvLE0iYQTMFJoqMwXg0GUfj0eQsGo9OxrCBWXQVXcMGjsfR8Vk0GUcnY3j5no3gkeUIpiwKwTGFyXhyBlwWpTWj0NdcN1/T0lVIGHeEe9o6PURbp36KyaulXzPB55pZrmRQY37YyethKscle7ZwCUxzm+VIWsuRSVALsBnC5NQvHUyhLBSaJ2iAS9eWMIEyZRpStoU38beH6OV79hb+Uul7A1fMIAjFUrjBnMn02Y7gVsGCbzAFWeaoecKEnxW4AZ4T4mlYy80KWloOCeOOcE/LZ4do+Sy8Jx9wgRplglBoteAivDvPwrvztTZoxaRG3KglSlUaUmgNIvxZMmm53Y7gKUNQmi+5ZALmTKaYgsOt/giaSGMhWIKp7+4AuKS97kygepPGhdIIDG7j77t3YQpzZlBwiWG9N6tp6T0kjDvCPb2fH6L38/Du/s2HSOfGEpUXTHPTs9HPwxt9dQqJ0hoTa6DItsZtvJSbgtkki1iSqFJaLpf+FRmTS+zgMYJr9150kPkN7rwLrLnNnEFwQ/62VuYFpAqkssCs1XxeWgQl0uHKDCWud28wSqDYglV+yjACzZJaCISEcUe4h8C7QxB4F9758SZBAVxa1IVG2+9o3oU3/02lavBpTKZEauB+azMlIVHSaiUE6sgosUINRrLCZMqaEXxWpRZbwBUTpbcMQogtlxqX7tlAaRD891H6UwpmRvAQP3y7hfs/nj7f3QJbWNRe5wSx9+WgNJgEJdNcQcE0yyl0mItqKiaUREgVGoeixqEqLM/5v3C3bcJoNQpooRUSxh3hHlrvD0HrfdheHi1Z9nILsyBG78M2cl358yH585zLKGcbsJlG4+F6YzKm0cBxdOJAmEQnby/g/rehkmJL6tWk3gvSj3tA2tfk8Mh4yLpKcnKPd9dHIBWkjIstaDRoR3DTDGEvaKDQmGDqPC1f+KnRvbOZW5cCDagVasGKMBTNOltQhIRxR7gHxYdDoPgQNpwdFFdBKD6EzWVyOsxUqUEo9TJkGbK0ipI/gIWymmg8ejd2oERLzdMWKHNmLeot4KZQ2l7AyfgnwBVKMoiWUtGgXuERHI9/AkUxY80NvsbPISEVGJ6XwjKJLni5GaLdXGFImvW2IAkJ445wD5Lj8SGYUK8f2sd1OB8ehw3koXECBpgl/ektOKBoH7rQIHFjCaU3k9Mj0EgVF5fLt6AxUTo1F8BcWmnAGQ2NWHBtLKSYcIpxpGtjo0KrzXbIZYLS8hWCmv8TE/pFtmOpDKHP8A6xStU0ErKYQmm54HYbrVEsKGJxmfKEWaV78tfWctvJfkgad6X7sBwfBMtx2Faum2XW0ZocfBij47Dl3P+22/TAZSLKFA3FhSW5c6fVygRA0/YvcQT3yF6qpgIlE3a7A8kq6NgRWKVa3iqqzIZyEoE5Sktp9JbyLZQLpRNML+DrPYX50scqwoMlCRYElNsC6wzl3gTOso8aC4Q5l0xvh1TNwWf+6fMj/PLlnt7jImZPytzSURvYkDTuSveBnRwE7KSnOqkypgPyh2qKPdtrsmduqgrCxwPaJUCoK2nKvHAWgX+WTBhnhjTkCO5/ezuCW+Skz+pbpNJVGo30VQaum8AOu3TFpdalobclWhnTTv0uPIC4GRbK2D2zazKWKtvrAalZcBukkDTuSvdBOqjepl4h6/uoNCbMWGCmVmQYoZ7qm4ppSsXIF+2K51YAs5qRcSu9BWagQL0g5DjZSe71tEulEdZcpmrtqhnyYJSEkRW7Dxyi1kp7ZmMEM2DCKHqzgUUpxK4sdWmMj5q4seSKewAI1u9BadyV7gNwUAlPvYJRCcVi2MTiRMkVef8+GHpK+iphNt3JGBU+SkJp2FwgoES93AKbq5UHjCiTvMxBKkmj3OZ3PauMgJAgr7YpBE+4FVtgK8VTA4YLlPScaGSugqrmnm8hESwvfFEFpUxRD+vXPN5d94ARLPOD0rgr3QfjoEqfegXpp7pIbGrDMAw91f4nzdOhVUPnsshTLStBnYiRizBIhYelsj1+ZoktmQDcVEGrE3hGnkzJVGmQggOknkPwGYYBB1J64ctQZy4WGEhciy3RKj62YAoo05ptoC8bJqW2jAtqrQwqDEuQBQhK4650H5aDiADqFbKRG1xqlv4gfPTU/5RUwSUUhsMG3lRG8Zcm8317BLProeEpmYNW5TIrSs9WJaxgCcXkBUudJ3JZrwftStmsyQ3a9UmVfpQaEmUs4dIicdjcJQQ4lGjrmrUGjWJNDwZBHiAojbvSfQwOogKoV8g0vkhuOS1DpuDZVtq2zurDmPRwAjMhwFimiSOBD+OfRnANGTP0k/bpUC2GPgyAJYiseyE1bpHpIcrUuRGicSFjK6xCRIJp08EPHMFH+kbyPqUZ8urzuXOvFI48f+aS5wsolODJtkUz+aSNsClKjS22YkjpjBB86epUi6aPIG4poI1ckBToSveRO4gWoF4h63moS4T41+NTX8XhLnEJY9fDFczugNI4cj2dre0mxk2h0VA1cwTrjCcZqJxb79GGRamTjHwZGcYIrp4o9V5x8nizO4pDZe36XPuNZ9EEm6OgDqzKlS2VWhbuJ/eeBrU9qg9yAEFp3JXuq/4gGoB6hanjSvV1elhzVWG19/ACs29HMPsjmv0juro+gqub6OpTdPW5gsJnXqrUCTGUS5xrRplWytlSKnce0qoEIU6UVDlP6PTPmYSS5qgqg0j1pmZbc0ob/BbpMNQa/yy5pgxhxXENc88u/1OVmjZCN9UfwRMmmXQB9dcZGdzt3RNg9QnRgqNIKWHm3rX3YBkkD4LSuCvdw3JyEH1AvUJmdP/4bNWz26TNsUkQx2qG/Wrm73AJs28whKtPpA2yFxfBCTBfzP9ZoqH90jqY2cE3orHkiJwBkg1w6QpnJaNCY87LPJJo6djYeWhTJQamnFvNXL/XBCcZIZ0NOB9XaBzSrPVeTZGMThneD05rpS1wgtK4K90H5yASgXoFE7fJPZUa0lTr7D/2rGcIxSW2Ylz4VNmxBT4I+ELQAOvqvLIaLne1YENXX3ivZ5jwBOb95L56yCmtrBgBYVFL5oiP3UjjqR6Wptw1dNg2mqIn2rSW1UYiWPV3pftIHFT1U6+gmZBvZtryhBfeZQie8x/U/tVEe9Zyq2BeblHXSW/CiiNQpXXpGjFyRIJpZx4rnpZMDL2LYt5nKWmsZlzaNi9DdAAdIKywmrsu33OXvTGx83kuOyBLqygHVw5g6tFJBC8KonJ0dQ+gB5NgkR+Uxl3pPiYHFfnUq886fE3cnL8Skx7Go6fSf/QxJtsWqOeULsHjzcMuka2VdeTqedeUMKckZkFJHME/UKtIUo72L9QKUqQoIMmxwYIJYWDOkhfi3ppDZ6d5bmrlX4Cs0avOpMmM6jeP4IttiqAqrGAKqSrnAoes9FabCGSaEnVSQA9uQW4gKI270n3cDuIGqFfIlr75zTikPb5oDqF50oNcDzkw+73mxmbfozeT/9u5sLeeh2xcGm4SxJQYUIGayQQ7bKRg8mUEs99Jy01+4U2CwldNITizbJWfbcfsvt5fCEBmOCHjoZ6rUqYe0R278MOrAa3VtlEKkgZd6T5KB5EG1Ct4SioY6YG8xv/n6npogz/qWwG7jNorJXpTX6qoeQQq39/6yEMHDVV2yQw4m2LW/W1ZGWlQ29o0KP2q+QE0lufOQBJWGqrlmmWoBdRHHr5Y8NOYEVzfQM70i6GN447FXRrj4qDxOWUvXEEyISiNu9J9uA4iE6hXyKhudy5whZovKLfqxauPV2gS4iOYM+Ethc7IKD3jsqSQ4jf0ERRqjfpoj+x3dfRa1Tk7T5rQkxIBaOkkwl09cBnhCL4zTYdKjtCrc+hXCXdFDLkjPm/adpeAJxkmLwYKZvoyiCDTEJTGXek+QAcxDdQreHjqA42/gURFfRibHn7hixtmeY7Gsrxwx0C5KyB3h5nubldNGI/gvokldaq3Y7Ln/rSuNKgdncMp4hur6jtMaoWS0K8DD5cpFigJQXfOPUzVWpLRYgpkMT2qD1IFQWncle6r/iCqgHoFiTa1prQJWQ7GlinHcKFaDd+zi6/comaWiok5yiQjV8Hl8oioeEp1BRRcKNuq+Y7IG1XBnqA2R20VVkc1BiUVIavabNKGDuy2aXQujtLP6nzUIJyc+4ObHtUHqYKgNO5K91V/EFVAvcK73l2CSVVSOifR75R6WAK6G2ymUZSqxIxMwoutuxCcqiRyT5Gu77FFtXMfCS4LrZbDjC8zM8psLsJKCtbgQWncle5fDj2oBqdewcMS7xoSlfZcEe2pvOclF+lz/Ovxc/zryeT5l1JYXl8HeH58mt3ezL7e3cbPq5Pn67uvs6vnj19+j2/eHL8dFduLJirvKgJOh7cpQsGSF7b0+cyuF93O83dU1ppb21cdtL61fYM0WDt3pbVSo1e3i3PUS7xG4S8e755A44I4qild240CTVcnU7qkGmw6ndLNymDT2ZQu/wWbzqd0Ky3Y9G5KV6CCTe+ndCUn2PRhSldDgk3H46m7oBBupFX3Lft4MnWHq+HGk6k7+As3nk7dQVS48WzqjkPCjedTx9OHG99NHRUcbnw/dWRluPHD1LFfwcbJeOrYl3Dj8dQRAuHGydRVpuHGk6krf8KNp1OXdYcbz6Yuxws3nk9dfhFufDd1ETDc+H7qfHS48cPU+aawAYynzsa8cXXtqGBL/MXRAwYELuzlYDx6NwDtvZb7bVXhfp0NYK6sVXn9REfgqOnpZAALpezuwb9p9y8eP/8HUEsDBBQAAAAIAGmQNl3j8NprXQkAABtCAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDQueG1snVzbdpvIFvyVXnrKeVB08TVZ48wCjC8ZXyTLspN50WqJlsQEaA20ZPnvz9qIrficxW7R+8nleFeBoKhqwM4ff27TRGxUXsQ6u2j1PndbQmUzHcXZ4qK1NvP2eevPb39sv77p/FexVMqIbZpkxdftRWtpzOprp1PMliqVxWe9Utk2TeY6T6UpPut80SlWuZJRSUuTTr/bPe2kMs5aIFj+61U5PMhFpOZynZgn/Xaj4sXSXLR6Jy3RgcGZTorqq0hj2MmWSOW2/PoWR2Z50er3W2IZR5HKLlrdlpitC6PT193Per9ldvR+Re/z6EcV/WhP75070I8r+jGPflLRT3j004p+yqOfVfQzHv28op/z6F8q+hcevddF33SZAnvj9ZgCaD0ALAE0HwCWANoPAEsADQiAJYAWBMASQBMCYAmgDQGwBNCIADgCfXQiAJYAOhEAS2Afgkwn9tGJAFgC6EQALAF0IgCWADoRAEsAnQiAJYBOBMASQCcC4AgcoRMBsATQiQBYAuhEACyBfSEznXiETgTAEkAnAmAJoBMBsATQiQBYAuhEACwBdCIA1roInQiAJYBOBMASQCcCYAmgEwGwBPaLQ6YTj9GJAFgC6EQALAF0IgCWADoRAEsAnQiAtcRGJwJgCaATAbAE0IkAWALoRAAsAXQiAJbA/kaF6cQTdCIAlgA6EQBLAJ0IgCWATgTAultDJwJgCaATAbAE0IkAWALoRAAsAXQiAJYAOhEAS2B/08x04ik6EQBLAJ0IgCWATgTAuvFHJwJgCaATAbAE0IkAWALoRAAsAXQiAJYAOhEASwCdCIAlsH+Aw3TiGToRAEsAnQiA9QwJnQiAJYBOBMASQCcCYAmgEwGwBNCJAFgC6EQALAF0IgCWADoRAEtg/zCR6cRzdCIA1uNIdCIAlgA6EQBLAJ0IgCWATgTAEkAnAmAJoBMBNBbo/H4rUL5GuJRGwje5fhN5OQRvEOA+bkfev1Mo3zzMYMbrtURRPkc3F63C5OVPNt+e41QVRqYr2MZmt6U9x6/nXEqj6saD+vF7nZll3fylZX7ysE6nKq+jhdRevddNX9VP3+h1rfh1/fhIJzIXciPjRE7jJDbv4tOv107a/0+dyE29yOBFLFSmcmlinQF/Wcu+rWf7slAi0TISlyqVWUQLfCc+w0obscrjmRKfwvFT556g/1VP16layInZcalN3zXbNEW/p05tnLzD9ROn61QUIGaVebDKyG1Dmcd6mWAp84USZpmrYqmTSERxsUrku11sQOxTXMxYesMmn3HwQrvkiRBQsxjejdZRRvWUcFKoZC7CYY/e2jNFrT49SRxTxGh/5EjuC+HGx2AyVYvYcg2+0kyVRSIcfun0+jT9B7XTizyOJkZPyus4HPbb4fCYlvlJyCSyMPEMQigcnopVrrfv4lO7VuLveonxZKazQoTDs9JltVSPqIxwImdmLRPYf8sx8Kj2UImRoYVH1MjlpFjG890lW08k+iScTKURmTLgUItFPaJYgkmkFsDtWrZ9Zbk0Ess2ib4JJ9P1uzDaSBuZ6JnXyT7b6nlEw4zNrtnC4Xmn/8XC/27LnsYqRM+MLp/ETK5WKrI727uzxXP7rVwCqUjkaq5ylR2qHo/ongG01mTQH4ADjg5oEMUTTuLsH+CfWk4m0TbjySrXxTpVOQgci1ytdA6fiz6wRNXIHiick8eTaJQ7iKpyzUIyiSpZyDSV1Tath43oFSPXwD47wCaq5TpXKhNTlal5bLsYiIIZvU52l1847J00OepE2YzhSt6dPNvFQBSOByHbs/B+2Fyr/gV6V0SxXGQaOuPAoSQKJxiBzs789USiZgYl8Zgm+kTH3AVAPLUQiXYZlkRLq/lEvYxeq4u83+Rs+0TXBKPycgWZ8yYyROWEw6OuyLQRM5nM1ok0KqqlX9mCeLfeXin5y37WfaKDrkflckWEw6MeRjH5QYgqGr3uNfpNjgfRTHBmcrVR2VoVFjbRS4MRLLnK/ZB5bJapgivBG7f9a4sYUU9P+zqJPhxl+wEmmmrwAvs1lcaovLyfJOhEM11Xa8nDAkQt+Tvifj1KCzweFFBbOLcWCaKUxoWcJqoNt8WLdwH3Ee0GC3uf6KrRYyCmMpFwenJVxBEsU2kVordGsVEuMiP6/Ig4LY/LTBeWDvKJChuXkQQrVz0XpX8P6IwtS+7KqbA0bIOs3bIvNqV1tcTzbtveY5PL+rWhmv9cflpa6Ad9XzbP5Wz3YKV+leL/tJoY7r/1erFcrW0uJnrOS1ZLuT+i9Q+FAqLqApnE0+qZ0G+z2U5OQHQfnNVIZTqNM2l0/qH2a1WIIvRmJt4oUVqk2+nV78HlwTvTSM3jDExBahDdN4rTdWJkpvS6ELsg+BgJpNyVJRL0OovEJtbJgUdvAVGFzyqHg5qIONuozOj8HfYss0VUQDWiTjYqF4Wa6SwqxFzn4i3OIv0mPhX1QkQn3sdbFbXjzKiFysVcJslUzn5ZDhDRjmGZ3O1qtVDWfHDAf0Q1Puh2YXQuFwpjjz46dwclDjVKcH9QQq/Kh63Z4kBuBkRBPv4vP85miYjUIpdR5SNS0F6YH3askBv4silEpgXuN607sOsmuigsR4xoTb+8QUllvig9jnks4RP/o6pQrTVEp3wF8eFNRP/DC4d+uTH4lV9z0dr9DcTmW7c2VqvR3uHRoBrtHx69bD4aNh+9aj56XY0eHR69aT5623z0e/PRv3aj8KcCh0bvmo/eNx99aD762Hx00Hx02Hz0qRo9Pzw6aq763Hx03Hz0pfnoa/PRH81HfzYf/bv5qOc5zPoOs4HD7KXDbOgwe+Uwe+0we+Mwe+sw+91h1iFoPIek8RyixnPIGs8hbDyHtPEc4sZ7cph1CBzPIXE8h8jxHDLHcwgdzyF1PIfY8Rxyx3fIHd8hd3yH3PEdcsd3yB3fIXd8h9zxHXLHd8gd3yF3fIfc8avcgb9SOjh77zD74DD76DDrkDt+lTtHTWafHGYdcsd3yB3fIXd8h9zxHXLHd8gd3yF3fIfcCbzm5yJwyJ0Ac+e0weylw2zoMOuQO4FD7gQOuRPcOuyvQ+4EDrkTOKx3Aof1TuCw3gkc1juBQ+4ETdY7+Dih83+/5riSC3VfPp4oRKLm5qLV/XzWEvnulxxLbPSqRCctMdXG6BS/WyoZqRy+O2qJudZm/83u9yr3/8/Dt/8CUEsDBBQAAAAIAGmQNl3QHOZLawIAAMsKAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDUueG1snZZfU6MwFMW/yp08dR8sUK1WR+rsWv+32nFHfY7kAhkDYZKU8vEdUqjODrgZnrgp53dyp9xDOL+oMgElKs1lHpJg7BPAPJKM50lINiY+mJGL+Xl1tpXqQ6eIBqpM5PqsCklqTHHmeTpKMaN6LAvMq0zEUmXU6LFUiacLhZRZLBPexPePvYzynNSG9tdrK14rYBjTjTDPcnuLPElNSIIpAa8WRlLo5goZr5skkNHKXrecmTQkwYxAyhnDPCQ+gWijjczemntfNjt80uCTYfhhgx8Ow48a/GgYPm3w6TD8uMGPh+EnDX4yDJ81+GwYftrgp8PwwG/nxh9osB+8gZMXtKNXF4MM2uGri0EG7fjVhbOB9xVCm9oFNbReKLkFZUV1YI8mLbyPsA16VGt+BwS0HVsTEm2UvVPOF1xhZGD9ChpFfLDRCKOPt/RXvWW523hv8afbYv0KUUpV8gN52U3eKM7+yy76GtcNaSQISVm/w5WDA1aFVKbf47rb4+/TJWhDfyJv+knMf+j6toerHxPbt96L3/XgUpSoQGMkc6ZhpDvh+254dbeGmArxTqMPGPle0Ak/dMNLuUUFJlWoUykYjK5enr2+7pfdHi9F4e6x6vZ4Ro2qRIgVjQyXOYwOOvHHbvypRCVoUfA8AbURCBHNGWfUoO74Szyb0W9RnXxL5MRuUL8MTUh2Z3I59zuT5y69dJcu3KVX7tJrd+mNu/TWXXrnLr13lz64S5fu0pW79NFB2o6b9885UdAEV1QlPNcgMDYh8ccnBNTulLC1kYWtpgTepTEya1cpUoaqXh0SiKU0+8XuYNp/l84/AVBLAwQUAAAACABpkDZdLyoj9wsEAACBFgAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQ2LnhtbJ2YX3PaOBTFv4pGT9mZTQwGEpIp6TjgJP1DA6GEti+MYgtbU9tyJUFgP/3OtRHt7lhE0ZOv4ZyfJfv4Wva799s8QxsqJOPFALfPWhjRIuIxK5IBXqvVaR+/v363vXrh4qdMKVVom2eFvNoOcKpUeeV5MkppTuQZL2mxzbMVFzlR8oyLxJOloCSubHnm+a3WuZcTVmAAVr/eVuKJQDFdkXWmHvnLPWVJqga43cPIA2HEM7nfopzBIDHKybbavrBYpQPstzBKWRzTYoBbGEVrqXi+qP9r/8bUdn9v993snb2942bv7u1dN3tvb++52c/39nM3+8XefuFm7+/tfTf75d5+6WZvt3RuWo6AQ/Ack9fW0YPCCaDDB4UTQMcPCieADiAUTgAdQSicADqEUDgBdAyhcALoIELh1IF0EqFwAugkQuEEODRBxyT6OolQOAF0EqFwAugkQuEE0EmEwgmgkwiFE0AnEQongE4iFE4PM51EKJwAOolQWAO830/1ahkwIorAjuAvSFQiWAF0fW0+rAmqlUMEmqCNkayeg2qApRLVP5vrEWHZDvib+igH/U2zfvKEElpQQRTjBTr5uUj/anIPm903RFKUcRKjEc1JEZsBo2ZAuJQ0W6Fw2jZbQ5M1SolIqNl4azLGTL7mvTN5E8HipeLLatbh1D8Np10z5v7ItDOz7YPJ9rzeIcUVOeL92OydK5YxtUPhtO/5l+gknD822j8Z7MtScLnOqYCL1UWCllwoGptBn5tBs8WynkA4bfcsMGPTeJ7Xu3owRybzpdk8nMGV65h9D4abpfJ1zb6Jcc4TfwJemxlPTYOuLgFQ+haUx2bK3axKMAqnnTYqBd/uzIiZcTYa4VsM5KvhXPoTJOiGFmsqzea56ULALViNggim0pwqFqFgfnpzZ2Y9mZIEQymoQnyFKmTEpTJjFs2Yh7JqokVS21kRZSimiSDxvrWaeN9MrVUpKnaIH7iSbGCzkajgSCouCDQwE/b7cWzGpTT3kB/N5jElBZIlr8+OZ3IHwRE7nOwTkmUo5Wsh/0ZHQTdHQDynCXllIIbH1pjGjBSIRIptKJoIFtEl/fUKy/AEG2ZcwmWZPQzN5zMIj0yEZkQqFkFzrm9IyM4aPkCgfyjc8Sen/4V61ULhj/WC/8eywK8OBK83aoDrLw2b61bjiqCWdvuvS4f20pG9NLSX3tpL7+yl9/bSD/bSj/bST/bSz/bSsb30i730wV46sZdO7aWP9tKZvfSrvXRuL32yly7spd/spd/tpT/spUHwBu0b+kvwhgYTvKHDBDYtRrdT738vYyVJ6JiIhBUSZXSlBrh1doGRqF/Fqlrxsqp6GD1zpXiu91JKYipgr4PRinN12Knf/g5fk6//BVBLAwQUAAAACABpkDZdTmHvifgWAAASaQAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQ3LnhtbKVdaW9ct5L9Kw19egOM6NqXh+c8dLwl3vftS6DYHVsYWe2R2k4yv35QbbefoxSdQDIQ+DrWIe8lizxVp4r0v/7927ujxcfVyenh+vjyHg7YW6yOX61fHx6/ubz3YfPLfuz9+7t//fbPX9cn/3P6drXaLH57d3R8+s/fLu+93Wze//PSpdNXb1fvDk7H+v3q+Ld3R7+sT94dbE7H+uTNpdP3J6uD11vYu6NLBGCX3h0cHu9Vg9v/e337w/dPFq9Xvxx8ONo8XP/6w+rwzdvN5T3UvcWl+sFX66PTz78v3h3WS+4t3h38tv3918PXm7eX9wj2Fm8PX79eHV/eg73Fqw+nm/W7Z5/+Dv/TzCc4fYbT+eD8Gc7ng8tnuJwPrp/hej64fYbb+eD+Ge7ng8dneJwPnp/heT44ws5u4JwNfDG8c1oe7kyvHs7VwM746uFcDezMrx7O1cDOAOvhXA3sTLAeztXAzgjr4VwN7MywHs7VwM4Q6+FcO9DOEuvhXA3sLLEeztXAl03wnJZIO0ush3M1sLPEejhXAztLrIdzNbCzxHo4VwM7S6yHczWws8R6OFcDO0ush3OR2c4S6+FcDewssR7+dgOX/sPqWzfg6sHmoP5wsv51cbL9ofIAhHbgLz7B1nN4VT+zxL3F6ZYHN5f3Tjcn27/5+N2d9fHm7dHv1cPHT/18QXzfI+4/XbxZHa9ODjaH6+PFP/7n2dv/6tBXevT3B6erxdH64PXi6urdwfHreQNX+wau/XS6Ovplce0BzqHXZtBXbw9O3qzmwOsz4OvD07/C3phh35wcvv5ps/5p+9XXHtD+tQcyb+aHb3z20Rz24wz284ffF5v15uAb2Js99snm8Ohw8/vi2oO4RLn4x7UnD1v4rQn8p/cn69MP71YnNVmyOFm9X59sVq/nDd3uG3r07KdPH3DtAerfaObO7H1+/vD7p5f5xsfc7cFXHtXM8Rx3b7JYtjiZ4+5Pv/k+3S/s3/niB7OX3k5BtRJ/o5WHfSs3Hm0teHHtAePi/cn6t9/nTTyafs2uCfobL/J4MpZ0f3Gy+rg6/rA6nYOfzCailuD2LQ5ODjdv3602h68Wyyf739+Yt/V0Zkn1KserzWL9y2Lb5Kv16WbezLO+mXvvt5vo8ZtP8MPjV0eL16s3JwevP2+ts/aez7bWzWZ18vti/aXd04OP9dvH08XxenG6WZ8c1AY2a/bFt5s9Wp+ezveQlxN6WR0cL07frz+NzqUZern8BrwG+x8HR0eLt+sPJ6f/vfhmQ99/o6H1u9Wbg794kQlt3Vm9Pjw4Xhy82hx+XC3unxy+Wv20+t+/aGvCYFeO1qc1LY/uXZmP5/LaNz5kdXRwujl8VZvzpwVZtvOhJIjF/61qxf9j/4+NXtq6Cl95DPSVY0Bnurh5cPzh4KR3CWj7UhJbyCdd4uN3pjxCEQWdlJy19QdaKJsPCg4MAzFFaj2BFookQzwAibWg6K0r0GIzRrCwYDIHqLbdXm+hYUMsjAXIwtOx9QX6N1YbzI5ORIwE3PJ/CxWGoRweLmyBFq0PcP5eb/ZQiKHpwRisDCbtON36JtaTFAwwrKX8FqswKCRDTZADre32TgvdVxiBIakBgRncjtTdC2Dv9ViEIQ4BkgpIHtiC7/dgw0GRDOAaTIbZsny/+IahCBA5G6Nqa48P+ykarCKWlOwSmdCO86MW6yMtwlHNawX1lvG4t2UZYiRYC9A8vB2oJz00RjIoGosbU28YT/t1G4PFOFgdjQNac3zWTw/HSGBycwE18nZ6nvdYGGBEDmzpKZoZ7fe+mKzdoQQcrugWqdou3pctFgayWigTaYCJ9hvkcjlDE5mlEqgDqPeLYdkzAgxiEXRljKB08Ha4l1emY8ZBTigUhNBbyLKnBR0hyjVoSWzE7XpY9rSwjyMdA1EoLQgw6Ns0yl/RKJ+h0eurn0+mPMrtmiIa4UokHoL9BnKlRTLjYMQyTbB085aCr7ZYRBuaTJLsgKogLY/2b+zDEzESyTy1NbDrLdJ4BLgl7N66pdH+hRVGIliEUO08LfSHFqoUQxI8jMLRvF1OP56/15s9lHwQW5AEMCJRa5O3JlgeSEaBniao0c7O7RYrPoq1AUjDLSRb7J0Wu1/7pVo6i4RHZrvn3b0A9l6PRR6iaSyWnAzU0+gECzgCzSBQyAmoNcgHvWmUH8oooYHl8LRj9bCfo4EBggCBVE5aaxqP+mUwxNhr7aWwg7WW8bh/4RgEiC4KbGjYLvknvWHYYAVMQHdFmdBoC80cEWbIjsRo0Pb6rJ8ejQHGrojMULPTDtTz2RizKoCbSUom9Cw62eFGOFKQUiKm9qP8ssXCQJUtCRUZqaO0e8aytv+egx0cnBABBI1as1r2fACDlIXUiTSRrd83lj0lFImKIZg6cKg490HDsmcFH6mubOFgzNwHZsueFfZ5IKKqOQigBol+m0blKxqVswHvwcmrty2HymS/pOGT1XBFpjGo7CJQNOrJs++OY5RVQWptVtzP77UeizAIAwPFy6vsI7PrLTZpIGM4OFvFsX0UOnllGxXgBJR/qNFuzj/0vYYMQCGIZGTJdnv98fy93pRvBPoSRkIi2C/9W7NxAgFz5rCE6Kf2dgslGBAKoWEqjhDt9NxpsfukPECFkQIRSHv2vAD2Xo+tqBuZlIHMxKMPB+/3YLZiMgthcFeQ1pYf9GtoZCoaALoxO1E7WA/7gR6UZJCpwrUK2jl61EJtULhbpmMaeO+APu7fOAcKQFCglKBi7dc+6S2y3F4S10Ss4PvM/rYj0BbrNjxMsewqJaSPQ/sJMh0KzikInOG9pPK8xcpI0wRN+oRs9/MX/dfaSDYyEghIpf6VX7ZYGMVAEOgEwoCzQHA5QUOwa6kMyoEJvSe57KkABoFSbc5Ermr9nrPsSWEfBiKFA1gwAkFCHz73vJADS8tRAnSG7D+6p4V9HFbzywRmAuBn1tKf2FO/Ys+zcvHy/cnhUcue2gc5wqN03Nz9amm0xbLKQE5liWAnaKFX+24Nh9VeS4LbYLDd4a+12PBhhOaRRaHYR6/XW6jLcDdNpAyRfpJu9C+MPsw9DNErquuX0w89lpJHsAIXodXaaFn0Av3enPTLtWuZqQoF9/vdrekYA2KFdIHc8+/tFrmPA83Vo2YIk7iX2u/0YBEakOxZ8nWQ9hve3YuA701e+9NW61vN3bBXoO73WIPtcGnxg4lwH4S2WBoiuc1LVEDJkO1oPeznd3hEmkEyJCt4O8GPWqwM4hCAio9YolcKH/dQHFbOSpE/ZQmkLY/2Q0Uj1VSk6B/JexX5ab94bbA5pxOzlLPT8mjfrdNI5/DSNtFC2tl93u9yFZNB1h6V7t5LwS/6CeJReiQwAGMo977ZS50xYXolGPjzrz4gW87QDkwhVKJMSExU0Z4UYGAEYpZrt3Xd++Bq2dNCESkzC6CIKRtq9hF0Tw0xmFIto1RCy+xj2J4a9isSLOUbFAXT+K+Y1L5iUvtTHNorudZOdYANJclv82iLZdMBOx1XBKNdjFcn/erA2gHks67a8mgLdar8lZZsj2HYr6frLdRoYGoKKiGjR+/B3+jfuHxpIkypjEEa9knRHqsSI5KVUd10wv0/XqDfmz2WYpjXthVQoUsfj9osexwVYIEzk/b7++0Wuu8lgYV5uQwK2QtRd3qsQYVK25Q3clK/4929APZej6XKYGGIWTkdAv22db8HB+GIkinB1Nx61+HBpOPhBABsWhsPWW8bD/v5HZKWQZEYBNT3+6jvFwdRiZvbRG7Fly2TtliBYSFYOxYSuPdixZPJWA1jCgXOCoYx+4i0X/kyygUWYraI5HbTeDaxySqkQPSEpECmdqie9/vcUMSKqyqzGtxr9S8mi3cwsSa7SZJPVNWXNmNSElYJDoc075NAy+UMXd0qeRIaE0yE0Z4WiklBXQHDVSxiIsn2xFBMus3QiaepVcquJ9J+lgcFVBAcIVjaUk+ks55TrGgMZJvMPrMH/IlI/Ssi9TNEevPD8aplUm+nOlWHg1GklkvsrZlcabGsOr4OSHsTu9r36zJKmTXPAAbtRY9rLdZiMCdrZXa4Zqul0haqPghrjqk0d5f2jW/0b0wyANhJjdjduM+LTr4WeWBs66gUxftR/vEC/d7ssYrDsvJ1VaGEveNwq4VGFUSpQhVicaWEWiZtoftYhJYgpSmRhPfp8js92CkHsLhuk8jZq6R3L4C912NJcwhpJoOXVfUhaY/NiCElkKLXaPWJpAeTfoejlGLolQQD1HZ+H/bzO0qLDs7KgFkZR0ulk1kaHFmza5W/Iu6dpcf90pehVUBWGXN16m3yyaRf35ZUkTuZmGpPpbOVXy47BZgGa8/CzybdAo4UTjGvWp2+Bux5i5WBVkpDlMCK2edlXvQzBENVMUtQppId20F+6TMqtap1M/z8axKUztBa4xxQglaA0kTcnaAxJCQ8q47MLCdk2DNDUWlUNjkqOiTBnEi0PTn4CBX1dJp44cueGPa3iWikCjwqia5nZupPPBpf8Wj8iUcnx3aiz2YxDE4CNjez3vG40kLZZNRC+Fyp05NoTMNRFAMAhaTeLq+1UKehUVpB1ktbXx90vYUajHKPDAkrgraeQ/sXxhjhVcJZ3iVQv1/90GPdaVhq1M5helZs2HHoBfq9OZnZkhsBpZIrMCmYudV3yzkczaq0V0tz7NOjMSNRdpaE0CTSPgd2p8d6wAi1KmkSqxKWlkMvgL3XYwlzQFqwZFjlsHsS7cGZOVKrylaYEfpk44MWW8mkdCdKwwipeuiWRPtZGpSYLJ88f+iJ4dEEKoi+nV0zlz6ifNxCwwcwFVK2emOfHp2Yho9twF+xt4P0XuzTmNbKkblVfiMnpXLPJt1uS/QiMxJTuFexn/eLaCQH1H9IGgH9AnwxWbwDM2qGDJFUe3n05cwwAKUUZeT0KtGb5EcnaHA11XIaYivx9gw66zqzyqilqpNKyZrU6PaDDQMt1JB4u2eV9N8zaG9dtbsDRkYGa8yi0b5rHqZaDnxVsCGhfZtE8ysSzbP50Q9vPpxuWhrNPhxFHc7EtduLaq9HX2mx7DDK/SbV2CZKeybt+3UdWCcEzIFk4s9ea6FZJWxYxl1JqejTjddzVqtgKVv5X6TXsm7074vlCXMxv3mZd7smfuixpuWqIAGa1bbZy7oX6Pdmj2UftcsCElgQ957OrRZbsZlWhAUJhpNKvdstdJ9ogAVUbhWtMqR9mW4PNrbyoys8MwDpxbu7F8Dem7y0lsdS+mjWZ0903R4bKSMpLLYVr+i9rptzDczreE6pI+W4tFb5sJ/hUUcZmLMEZaPse340wSplkHqdSKrDMr2yO1m95XWQkRp65aJ7Mp2MNA+vA2dYJxMizxxJ2JFpi5UcxWblQBMXlbdkOpukkV6RYTBFiTMtmfYb3UhCqCQpggNItIvwRT9UJSahc/C25Ah7ze5lzuiwgu5Mqe/VSXpluZyhhcStjtt4pUgnpNQTQ9klkziqCwor9zLJ8srUrAWBsMp8Uz0mReTLnh3qMBaaI0GVO9mk654eSmbBUMo0oFQH+gs6RfiKT+tqoD8e9V6936ze/bw6aTm1frzbeFUHZVZSLKL4piXVHlxlRztC3Qq9LanOOo6BklVAUBIX9qzaYw1H6RYAxFsvpn3n6z1WcbiEap0HAcE+A3Fj8s4VjRtQJbUdylpbZp2AsSTxEvIoufB9jHqRnm/OhhpH7X81XiggvVR0qwe7DnJRlirWCu9J/fZkrMtHTpMI86yUXkuuPXafxUduD/uWuEUTgfruhdD3JuiaqvIGMEmrdqOdqvsTsAIPIlTN2vdBre36wazrKkNiUq98j7thnzydzPTgGnES0Kq87MuuHk163u6DzsyhXGXXvfj6uEeTDUG3SioSa0wM9MlkHymWraM4gZZQZwFanp0YWR14ysTK6SWi9yHgs8lHew42CmNAZuT+aNnzmXmTYRR1WFSFXh+39tgs6ZerQLWKkaNP3r7ssVC1dSqcuqtI6sO/5RRuGFzHLEuj81nwOWGMil0JmJhBaFuVNGHbuZlhqQTChszhPJFxJ7wRQ9g4K+o1pZTJGdPp6iKCqigOr2yOnBGS/ky4f7jFCc8Q7r1Xm/WUbrGX/JEHQIC5S10m0M7clR7MSuM/GVXuj4xfnXTMMcSLQsAqAT/Rg3twZB2FpoQK0dL7k9DXe6x7ZSiFKo71WUL2xuylvU5jhFKIGlmfs/th0nHoqM3flQV7IfrHi3R7czbDMuocRxUKcJ2E7rm2xSZsM2eVjwmaFezc7rHEg6ByQnW4tmrJ2y++04P3UXTktixCTKxOgPZkexH0vQnaqzaaxcDIMq1PRd2fgEtVdgmUhPK+J0rYg8mYjahbECIrTxmVnO25dgLG0u28Sv5o5tw86rEyUrLkwyyHroTLnmr7bcCHglX9rGvp2m3HTyYvjaPEjhQyopz0+3SyoGSYkzFEggPNeLafJ7ERtNVnWNNrF+qJtkVbFUlB1jnSOtABfc3Ai9lqrosFim5qzyfr6/Zf9uAiK8w6Kh+fz9H0fLPlhp6pq3AvkLAUeetX5XLCFnWKxuqUoRVfmM0ynhO+qGOoQXVqN5wNoWLrCdXOhj2oPCrHBMrem1xOOGOfBnMdGSRH55JO/+I+B/z6XqS6dPYPVHt3/fEboW1/O0tUOiOq9Llkgd7LudJjGStL/eVUas9aV3tspVHqGogUZ61baXqm7S9HsiHqEq7gRDY5ltpjA4t4QLdXLHDOItvJjUFViwCyVY7qCGJ/MrUHi5VPw2xCmViz3pPtBXq+2YPdhyhXSU9t45Ni4Jl1jKrGzxQIrxKonmtbLOkw8u3lO45cYnfPtdObjtJIpQ7k6uQg4d0LYO9NsKx1HreuDijld6Ka3J+AwwbUuVbOMMvo04oPJsM1LCi0sm3hxL3E9HBiHqOuAEiPAFLJXhd8NLHLQYwoEalV99F7JY+nU8xhTlpnrqB3tZ9MoFJnCETqPG4ETg4+P+3BWgVQXCeQtBJ8vcL+bDJJVEcf6w4NEkRL65WH55Mtr4LwlFIxteoBe8XkxWSaZCRnnU2POl2jfYL+ZQ+uRGwViinsfs1IdgKvA6J1lUaQ1lUP/ZsvJzRR8SxGGH059jHh2Ol9ScUtte1lkLj3/sVyQhZWteNSOlEJ1z65J2rCFvtl4epZkUZAnj0q92eK/frOpLqW/Q8Ue3X16hsU29+DYjmkorq6yM8nl4pc6bGsOGgXyTL1KsLVHovMQ1DZK3WH3DuT1ybYyghVLTcZ1g1bk6RsD85yY71ShZXUxV61vjHpmGBUesQiqJSTiXjcDxbGyCKrkks4J3Lmjxfo+GaPdR1eae9gliiZrafY2Q1VkSKCCWpifZXw5HtzVEG01mkMJu1Vnjs9trJ2BBElEkEVh7TguxcB35uAkUbFkiGVFYnkfi+5P0GzDaz0mUgkOvZa5IMebANZ1Oq8vte9MT3ZPZwYyJCa3CqfrXsgbHJ8dTLLQ4Ox7j90ZuA+QHrcY8nqfKMD1GFh612/JxMLiYpkU8vz86BeJn86GSwdQKU9fqq67Q/dzKbYh1UReV3/UuVsfW52AoaREVwXC1ShE+jk4M1klnyUF+TBZkoafUDzsgdXIAuWAMhVTWIwudBoSws9RaPWYSG3chGo94iWE57YXgeBW3UKCjsLY6e3KWFoXQ5U518CbXYdBLb42N6P4nUiBIEmmfjlhC2qBF8qLU1Yfo3LmfqBHcdeOvOvA7w/eLO6c3Dy5vD4dHG0+mVzeQ+G7y1OPv3bANvnzfr99kn3Fj+vN5v1u92f3q4OXq9O6k+8t/hlvd58+cOnf47gyz9v9N3/A1BLAwQUAAAACABpkDZdD39bg74EAABXIgAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQ4LnhtbL2aUW+rNhiG/4rFfQMYDKQ66dFpj6btYlK1M22XyAEnWDU2s02S7tdPJmm6VTZ1MkJuEpLv80seWcCD+fL10DKwI1JRwVdBvIgCQHglasq3q6DXm7si+Prw5XC/F/JFNYRocGgZV/eHVdBo3d2Hoaoa0mK1EB3hh5ZthGyxVgsht6HqJMH10NayEEZRFraY8sAMOHz701D8LEFNNrhn+jex/5nQbaNXQYwCEJrCSjB1egctNTsZgBYfhvc9rXWzCtIoAA2ta8JXQRSAqldatH8ef4vfhzm2w1M7PLfDS9qTU3vyng4vaE9P7ekF7eE7hIHad6yx2ZBiD+RQZICZcY7NZ4QD6MrUfIsDoFYBCoBeBUrL4Zfdw1NDqhcgJNhjySnfmqjdMfDc+mhv/QOzntjqn+z1v3BNZCeJxpoKbmv8bm/8UYnuv0Hh8Nf/RcAQ1KsgQWME4DB6Aj8MX2FG13LYqbLFhxKvlZXCsT2LhvbjFN49wEWeI4RylMUog8UyTsldnFupOOJ/J1XDaYVZiNmWrCWmFXj+9uMHqAVRgAsNiNJ4zahqAKkEFy2twg0lrAY7zGhN9evCCtOR9yTartekBhspWvD8qhvBAZYSv6pxxokP48QeqkRVrjHDvCKjjBMb48iKM5kZZzIxztQHZ+rASTXx4pnaeBaLoojzIo2XeRTFEEFyF2dWxunMjNOJGSMfxsg9ZSvBNeU91a+jlJH/rEUzE0UTE818iGYjBwHR83qAuaOCOc8Ej5k/0mxmpNnESHMfpLnj3NVguSVlJ/ZEfkI09yeaz0w0n5ho4UO0sIfWVF0AtfCHWswMtZgY6tIH6tJ1vmp7pjEnoldlI3ppP44u/WkuZ6a5nJhmHPngNFWOS9aqP07Lkgu+oZxq66X442kEL6autJtBdQVeTzX2ohrbYzvYlYrybc+wLDeYsTWuXkam62mcD2zjpLDTjeemG09N18uyTJUtlpMt1nRHSoO5k7QiDqp2z4KxnercVuUKvJ6ql1eZqlGq6/6VyLLXlJmrVVyZL+18rY4FEXIAntuzXIHXA/YyLVPlAbjFcks5ZqOErdYF88JxYJjbslyB1xP28ixTZYs9khwOCyPHWqtjJQla2pnO7VmuwOuZepmWqbLFbiWtS06wLP8mUoxxtYpWihCyc51btlyB13P10i1TZVdYtiOy3FNei72D6AWi5Yq5Hc6pVSv2ci1TZYttafd+oTUK9QLRcoXdDurUqhV7uZapGpmjyvyHWpVaaMzsUC/wLVfY7aBObVzDGs/nawQOJSG8Ls39q5byXpVKY6nLl31j5Xoa4wPXu2gRRWkBkwzmxTJH6TJyXBC49uF2KwVTexj08jBTZbVbVXaqpDXh+rM7r9CuYIs8zxKUFckyjSKIIkTuYvsJzbUPt2M9tZVBv7Uvh7aQv3rMztrgxxz+X+azr4RN7WzQy9lMlS1Wv/3PssPKwfgkafHQun5jbMc5t6G5Aq/H6WVopso6hXeY9cd7Yadznh2p1cqiRZRESYSyODIvmGfQsXo7t6XBiSwt/PDMQIe35NfBYhVgZKNXQbTIAyCPwIfPWnTDJxSAtdBatG9bDcE1kWYrCcBGCH3eOD6kcH5G5OEfUEsDBBQAAAAIAGmQNl1ySCyKwigAADN1AQAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDkueG1spZ1Rbxw5lqX/iqD3DZMMMkg2pnrQuSlmYIHpXczsYDAv21DZqrLRslWQ5Krqf78IlbvqnohzM3kzntx5+1ym/VmV5heMjPsv//rr58ebnx+eXz49ffnu1g/u9ubhy/unD5++/Pjd7dfXH/5Huf3XP//Lr3/65en57y8fHx5eb379/Pjl5U+/fnf78fX1pz+9e/fy/uPD5/uX4emnhy+/fn784en58/3ry/D0/OO7l5+eH+4/vLV9fnwXnJvefb7/9OV2WfCt2t7C/+f55sPDD/dfH1///emX+eHTjx9fv7v16fbm3RJ8//T48u3Xm8+flt/k7c3n+1/ffv3l04fXj9/dBn978/HThw8PX767dbc377++vD59/q/f/j//xzK/tYdv7eG69vFb+3hde/zWHq9rT9/a03Xt07f26br2/K09X9devrUXQ/u7P34A3n5ijvev98uL56dfbp7fQssPSwz/bP79x+fth+z9kvmLv715eUP2+t3ty+vz2//z85/n52Xxn397i9/DBx7+t6cvrx9Z/n+eyf/tr18/f/9A3+bI2/7j6fH++W9/+fn+0+P9958eP73+42//fv/L3/7+X+8+/7/A1rnrXuc/Xx4+nFmo/b7Qu99rJ774X59eH9gSM48fHu+//P3m5enr8/uHm/cPj48vN788PD/cvH/68vPD8+vDh5vXpxsHC757+/sVf81B/G2Gt3cZw9vb/PZZ8vOfPf27hOgfv6P/df/l6/3zP+hfZ//qRxp19G+pP9r+iIq/COUP8t8P9883Pzw93zz8+tP9l+UjnP69KN3BhXQe+yiwj+yPQH+UDqMd+9iPfezH3h9tI8Ou/EH+79Pr/ePNx6evz4//uHl++uWFUqdvXvJ04Uc9CuaRLTFS5tHOPPYzj/3M+6MtMuasOENxgywJZIm9faTIkh1Z6keW+pH1R1tiyFhxTmeRTQLZxN4+UWSTHdnUj2zqR9YfbRNDxorzdBZZFsgye/uJIst2ZLkfWe5H1h9tmSFjxTmfRVYEssLePlNkxY6s9COjUTc4mr4zpVth4FhxLmfBVQGu0n9HKLhqB1f7wdGoGxzfmJrSrTJwrDjXs+C8k/t+x34PlW/7nZ0dX5/D41k3OPrP+Z0t3kRcbt9ZdcbqliCYk6d/QvqpccBwJ0JvQEizbnCxxjqOrkQ35ZzpZ8rdnuYmmiVeVp2xusUrVcZz2+Ayg+FOvAad4Vk3+Km6VH12paaQ6QfP3Y7eJnolXFadsbqFK4XFc6fgyoLhTrgGaeFZN4RKP47ujPkm8hIiq85Y3UKUBuK5JHAHwXAnRIOF8KwbxsL/7Tbmm8hLiNRIsLqFKJ1kuZRJ/ozcSjDcCdHgJTzrhrEqH5y2fBN5CZE6Cla3EKWleC4S3FMw3AnRYCo864YxUwm4M+abyEuI1FqwuoUovcVzteDmguFOiAZ34Vk3jE75SbTlm8hLiNRjsLqFKE3Gc9ngLoPhTogGm+FZNwS+i7gz5pvIS4jUabC6hSitxnPx4F6D4U6IBrPhWTe4ovznbMs3kZcQqd9gdXslXApO4ALCDQfDnVfDDYbDs25wju8Zjfkm8vLKOHUcrG4hSsdZzqC2v4/AHQfDnRANjsOzyqFCf7aJrIRHDQarW3hwGEM3/kE5jrnmPMZyIGM5kbEcyfAzGWooWN3Ck4YS+JkKNxQMd8IzGArPKvAMBysiK+FRM8HqFp40k0A394GbCYY74RnMhGcVeIYTEpGV8KiRYHULTxpJoJv6wI0Ew53wDEbCswo8w1mJyEp41ESwuoUnTST0i8IBs3+waw/fP+vw6BvQj4UjzyrwDKcmIivhUQPB6haeNJBAN/HKR16+Bl7/Gxx5VoFnOD8RWQmPmgdWt/CkeQS6eVc+8so18IoBXjHA6882kZXwqHFgdQtPGkegm3blI69eA68a4FUDvP5sE1kJj5oGVrc3f0jTGOlmnV98wWwnPP4GHB7PKreA9GebyMqbQKhhYHULTxrGSDfq/KILZnvheQM8g2EYsk1kJTxqGFjdwpOGsYS2vwd+sQWzvfCCAV4wHR7b4k3EJULqGVjdIoRbt/itSBzheA3C/pvDjjyrHiPb4k3EJUJqG1jdIpS2MdJNO7/QgtlehNGAMJrOkm3xJuISIXUOrG4RSucYuRLw6ywY7mWYDAzTjsPkPc1NNEu+VEuwuuUrtWTkWsK9BMO9fA1ewrN9p8k7epvolXSpt2B1S1d6y8gPNpQbYK8RF/4OCt1sO0425pvIS4pUYLC6pSgFZuQnG9xgMNxL0WAwPOuGmPhlf2O+ibykSE0Gq1uK0mRGfrTBVQbDvRQNKsOzbohV+efIlm8iLylSpcHq9t5qqTSRn21wp8FwJ0X+Dpwiz7ohTnxracw3kZc3W1O3weqWonSbyA83uNxguJeiQW54drlZge8ujfkm8pIilRysbilKyVm+v0QocsvBcC9Fg+Xw7HLQrvws2vJN5CVF6jlY3VKUnhP5cQcXHQz3UjSIDs+6gX/C3NniTcQlQyo6WN0yhK+c8FMPbjoY7mVoMJ2oqgvfORrzTeQlRf4dlPOuE6XrRG4i3HUw3EvR4Doi+8ef546voHxThzoLrc5Y3XKSzhK5UXBnwXAvJ4OziKzkZDg1oSucaHXG6paTtI/I3YDbB4Z7ORnsQ2QlJ8MBCV3hRKszVrecpF9EvvtXvjJ3jV8o78A5sZ3+HV9B4UQNglZnrG45SYOIfH/PDQLDvZwMBiGykpPh2IOucKLVGavbLxNKR0j99z8dMCu+Cn7//J5/dZyvTn9YjyIrGPEVlK8OUgOg1RmrW0bSAFL//vyA2S5G3sCI7cPv+AoKI7q/p9UZq1tGcn+f6A6ZfyxhtotR/+pHkZWMDHdD0RVOtDpjdctI7t7TaPjq7mhmNBoYsV30HV9BYUR357Q6Y3XLSO7OE93f8ksWmO1i1P9986PISkaGe5voCidanbG6ZQTfAKf7Wn5BArNdjJKBEd138xUURvz73vwL3+f33UnuuxPd0/LLDZjtYjQZGNE9N19BYUT33LQ6Y3XLSO65E93P8osJmO1ilA2MlKv3zkV+LcHa0ESDZEj341jdMpT78UT3uvxiAma7GPbfDnXkWTe4iV9JMOabyEuCdKeO1S1BuVNP/Fo/v5KA4S6E1YCw2r5qYsw3kZcI6SYeq9vHW8hN/MQ38XwXj+EehHx5jpBnl+vN/KfQmG8iLx92Qff4WN0ilHv8iV/l55t8DHchNGzyedYNaeQ/hcZ8E3mJkCoAVrcIpQJM/BI/dwAMdyE0OADPumFSvqljzDeRlwipIWB1i1AawsSv73NFwHAXQoMi8KwbpsQPPY35JvISIRUIrG4RSoGY+OV95Wk/ZoPgyysIlWv1E7/8e2fMN5GXCKlfYHWLUPrFxO9j4oKB4S6EBsHgWTekqCC05ZvIS4RUP7C6RQhPnOK3KnH/wHAXQoN/8KwbIj82vDPmm8hLhPz5U+ftZJJ2MvH7kbieYLgLoUFPeNYNQbl1wZhvIi8RUjnB6hahlJOJ34zE7QTDXQgNdsKzbnCV34lkzDeRlwipnWB1i1DaycSv8nM7wXAXQoOd8Kz+9WNjvom8REjtBKvbJ8lJO8n8JiFuJxjuQciX5whFVlyL4SsoD46j/kGrM1a3kKR/ZH7GwP0Dw12QDP4hshKS4ZCBrnCi1RmrW0jSMDK/xYcbBoa7IBkMQ2QlJMMpA13hRKszVreQpENkfgcPdwgMd0EyOITISkiGYwa6wolWZ6xuIUlLyP1ffT5g9g9Gf/np+dMjZ0RXp38DR5GVjAzHDHSFE63OWN0ykhqQ+2/AOWC2i1H/c2yPIisZGY4Z6AonWp2xumUk9/m5fyN+wGwXo8nAiB4z8BUURnQjT6szVreM4FGydDesfB5lM6P+1Y8iKxlZnhvLHxzLnxx7fqee5U490+0uv2iB2S5GxcCI3tLDV1AY0a04rc5Y3TKSW/FcDc8krmZG/V+ePoqsZGS4nYeucKLVGavbRxDLvXZxhocQOysjvjpnJLKCEV+BM6IrnGh1xuqWkdxqF7qT5dcVMNvFyBsYaY9sHbkUG/NN5CVBug/H6pag3IcXus3llxUw20UwGAhqj2VVrlIb803kJUG6ScfqlqDcpBd+oZ9fVsBwF8L+O42OPLt8c45/NdSYbyIvEdItPFa3COUWvvAtPN/DY7gLoWEPz7NuSKvxI78jtOWbyEuEdIeP1S1CucMv/EI/3+JjuAuhYYvPs26YMs3fGfNN5CVCKgBY3SKUAlD4hX5uABjuQmgwAJ51Q47KZ6Et30ReIqR+gNUtQukHhV/o54KA4S6EBkHgWTfkrPyHbMs3kZcIqT5gdYsQRk/wC/3cHzDchdDgDzzrhjzyLyga803kJUI+guK8XRRpF4XfhsT1AsNdCA16wbP60bsx30ReIqTygdXtGA8pH5XfhsTtA8M9CPnyHCHPLvfE8P+Qjfkm8gIhrc5Y3SKUblL5bUjKMBSznPDlFYTaN4cnBaEt30ReIqRygtUtQiknld+GxO0Ew10IDXbCs27whW+tjfkm8hIhtROsbhFKO6n8CIHbCYa7EBrshGeXB9FwgqZ4E3EJkLoJVrcApZtU/g1g7iYY7gJocBOeXU6B3agwtHY00SExUj/B6haj9JPKTyC4n2C4C6PBT0RWXM7iK/DLWXSFE63OWN1CkgZS+fd/uYFguAuSwUBEVkIynEHQFU60OmN1C0k6RuVf/uWOgeEuSAbHEFkJyXAIQVc40eqM1S0kaRG1fyrDAbPy4FiZwtZ/wHEUWUnIcARBVzjR6ozVLSGYVNf/nd8DZjsIVQMhegDBV1AI8Xl0fCDdpYl0OJKu/36cwyp8GZKyOqckwwKTsgbnxNc48fK8KhNUMHvO9W/HD6twDypvQUVv+lHW0FDxIXK0PK/KBBXMkXN0a6zMRsJwD6r+1Y8yDKgM9/7wNU68PK/KBBVMhXN0D6xMQMJwD6rRgoreAKSsoaHig99oeV6VCSqY/eboVleZc4ThHlT932U+KuHlSbpct60NTTYASD79DcsEJMx/c3QjrMw6wnAPyGQBqT26VHlCmrWhyQYAySfAYZmAhBlwbrJMdJ2sIPsnYR+VsBuCU2ZGGRuabACQfAoclglImAPnsmWwK6Z7SGYLSW2u26SRtDU02QAk+Sg4LBOSMAzOFcsMV0z3kDSYgRJ2g8bREm8yDhT5LDgsE4owDc5Vy7BWTPdQNNiDEl7OXJTht8aGJhuAJB8Ih2UysBkEQxlKrRiGNvZaJcmXV0hqU6wL/4u9szY02SBJKpOvL46+xtnX/LRBERBt+rVO0iIg2vjqEpSfSWNDkw1AUhlyfUFPcMy1MoZa8RNt0LVO0uIn2qhqbbK1Ld9kHjhyd7k00BonWisTpxV50WZa6xwt8qJNqNbGr1viTcaBIteaSxOtcaS1MnJa8RptqLVO0eI12ojqVPhhtrWhyQYgyb3m0lhrnGutzJ1WxEabbK2TtIiNNqc68n/67qwNTTYASS42l2Zb43BrZfi0YjbaeGudpMVstGHVIWofkbaGJhuAJDebSwOuccI1nxKtnM6u0j0kLWajTax2RSNpa2iyAUhys7k05RrHXPNR0cox7SrdQ9JiNtrYaqfZtrGhyQYgye3m0qhrnHXN50UrJ7WrdA9Ji93QqdN3yhrKRUdlnrUy0PrCRGsPI62XV4yV4i/aUGuVFV9eYUWHS98payis+NhqXp5XZcIKDEUZXa0Yija7WmdlMRQ6S/pOWUNjxR2Ej6lelQkrcBDDIOnDKixG3n798qCwosvTz5qjDAMryxkJH0rNy/OqTFiBZyiDqRVWo5lV/xHMUYaBleWQhM+g5uV5VSaswCb4OGft4yqaWUULK/ptaWUNjRX3BT5zelUmrMAX+PRm7eMqmVn1P/n1KMPAynDPEl/jxMvzqkxYgRHwYc3KJRNtzPQZVpOFFb1zSVlDY8X3/Hyi9KpMWMGen89mVi6LaFOlz7DqX/4ow8DKcAcTX+PEy/OqTFjBrp6PYlYufmhDpM+wKhZW2iY9uFRCTbGWsQTlO067upvsBsZ8v39h0LSHSdPLK/I7Uy6LaLOmzzDu/6r3UQm7wXtX6rgwCqM2HmtPc5PNQJhbwoVp1B7GUS+vyG9MuVyiDaTWCfPlFcLKiOkhhJzr5HJ2Y6xB8dQdzU02S8J8YvWqTAiDW/DZz9oJsTa2+gzi/qHYRyX8NqctTWPKOaXIFfFuR2+TvQCYC8mFsdYe5lovrxhgxUgw3QXYYiQ8/PaF0THHybsUQpqUa/s7mptsBsTcY7BMEIPH8OHR2qmyNvr6DGKLyGiTrIsPKY25xJpLLsrDT3d1N9kNkLkAXRiM7WEy9vKKQVYMSBuOfQayxYC0WdelTNVNpfjkahm1n+Prm5tsBsTcmy4MzvYwOXt5xRAr4qTNzj6D2CJO2vDrUqZcYsxx9FNWBhPsaW6yGRBz3bowO9vD8OzlFUOs+JY2PvsMYotvaQOwS6xxrD6FWLPXrnzvaG6yGRBzS7swQNvDBO3lFUOsaJo2Q/sMYoumaROxc44l1VyKDzHkxMdp7+pushsgc727MF/bw4Dt5RWDrPidNmL7DGSL32kDs6eUcxhTCDWNwWn7tuubm2wGxNzuLgzf9jB9e3nFECt6p83fPoPYonf6NO3ixuimKdSQlRkne5qbbAbEXO8uTOb2MJp7ecUQK36nDefWEfP1FcTaqO3R+xyTT2mKmt1d3dpkq8TLJ3avygQvuJ0yUltxO21q9xm8FrfTZnD7kGKaQoy1hjgqHxI7mptsBsTc7i7M8/Yw0Ht5xRArdqeN9D6D2GJ32oBu58cphjIWN03Ra1+l2NPdZDdA5n53Ydy3h3nfyysGWfE7beL3GcgWv6Ozt++UNZQLv3yqNy/PqzKBBZ6mzN1WPE0b7X0GlsXT6IjtO2UNDRY3Lj69e1UmsMC4lPHainFpE7zPwLIYF5/frayhweLuxEd4r8oEFrgTn5CtfdSp6vSo3IbAl6c72qMMAyvLURWf4s3L86pMWIEEGeZsH1bhLlbZwoofVVkGefM1Trw8r8qEFbgMn5StfWAVM6v+k7CjDAMrw9fu+RonXp5XZcIKpIRPy9Y+r6qZVbWw4reYWQZ68zVOvDyvyltWMNR7eUV+I8qlHm2st86KL6+w4nO9lTUUVnyyNy/PqzJhBarAp2cr12y08d5nWHkLK36LmWXAN1/jxMvzqkxYwZ6fT9FWLr1oY77PsOpf/qiEz3xh2tjQZAOQ5Bv7C5PAPYwCX16R34xyhUUbBn6G5GghqT00Szs0NzY02QAk+a7/wrxwDwPDl1fkN6NcSNFGhp8h2f+IgKMSdoOvLk3BjTEWn5VHEO5pbrIZCHNVuDBt3MO48eUV2/0qF1O0ieNnECcLYuV8ZUzO+VxcnEqYlEmpe5qbbAbEXDAuDCv3MK18ecUQK4ahDSw/g9hiGMps8mHyJYUc0uScn5TRd3uam2wGxNxLLsw69zDsfHnFECtios07P4PYIiba/PLicgg5+BxDLLEohzN7upvsBshcaC4MQ/cwDX15xSArRqMNRD8D2WI02oTz5Zy7+hh9KSFpX/na0dxkMyDmHnRhWrqHcenLK4ZYESFtYPoZxBYR0iagV1fcVOJy6F29+mN8fXOTzYCY69OFaeoexqkvrxhixZ+0geo6Yr6+glibkF6KH1N0cfI++pAVxnu6m+yWkPm49VWZQAbvUiauK+KljVw/A9kiXtoM9eJzdDVkN7qYk3IGtqO5yWZAzHXtwjx2DwPZl1cMseJr2kj2M4gtvqbOWK958mMc3TSlVJVP4x3NTTYDYu5xF+a1exjYvrxiiBWR00a2n0FsETltBnsKvk5TCvm3XxTE1zc32QyIueBdmOfuYaD78oohVgxPG+l+BrHF8LQZ7WP0zrmYY64+KeOb9jQ32QyIueFdmPfuYeD78spwXK6NfD+D2GJ42gx3P06uujKOKaWiXZrY0dxkMyDmhndhHryHgfDLK4ZYMTxtJPwZxBbD02a8O1/q5GvJzoVUfHYa5V39TfYDaO55F6bGexgbv7xioBXP0wbHnwFt8Tw6w/1OWUO5oMunw/PyvCoTWOBrfMy6dmSujYg/A8via3Ra+52yhgaLmxcfBL8qE1hgXsoseMW8tGHwZ2BZzIvOZb9T1tBgcYfiI99X5S0sGPq+vGL/anNW2tT3v3z98evLK6fF34BuvI4yLGlZJr/zNU68PK/KhBbIkDL+XaHlr6DVP/TyKMNAy3IMxWfA8/K8KhNa4DWGQe2HVbiTVrDQ4s86sMyC52uceHlelQktUBQ+b1351NIGwp+l1X+WdZRhoGW5iYxPhefleVUmtMA2+OR15dKPOhr+HK1oocXvIrOMh+drnHh5XpUJLRAHPoNduYajDok/R6v/wdJHGQZaltvI+KR4Xp5XZUILHIBPY1cux6jj4s/Rmiy0tE38clUwjsWFWKYcfK3KgeXOBZpcAFhzDbgwc97D0PnlVS+Kwyrcybr/DY5K2A0uhbGEMi2+lIJTH/a1r7/JfiDNHeLC5HoPo+uXV+T3plyeUYfXnyNdLKSVcxs/BpeSdynWkKPywIUdzU02A2OuHlgmjEE9+Gx57Qge052Q+5/ocFTCy/MQXS1hym55eoLTPjaub26yGSBzZcHyFnIBZeHD6bVDeEz3QebvoEDmYTckH3yMIeeQS0hZOYff091kt8RMy/OqTDCD6/Ap9tpBPKY7MVtkh4fdkFN0yaUphVqmrHw7Z0dzk80AmSsSlglkUCQ+6F47iMd0J2SLI/GwG8pY3VhCcmMdfVH+8dvR3GQzQOZmhWUCGcxKjKvvOIrHdCdki1rxsBvKlJL3qeRSXI0a5Oubm2wGyFzIsEwgg5CJgfYdh/GY7oRsMTIeXn4Yp+UkvTifpqloH8rXNzfZDJC5x2GZQAaPEyPvOw7jMd0J2SJyPLx8rJbqwhj96FPWhqfsaG6yGSBz/cMygQz6V/hNfor/YboTssX/eNgNU0jFxRqcC+o/e9e2NtkKgLnzYZkABucr/BY/Rfow3QnYIn087IY4ueKcC2Mea8qpaj/He9qbbAfQXPmwTECD8hV+m5/ifJjuBG1xPh7uB72nvcl2AM29D8sENHhf4UdOivdhuhO0xfuKqm65ej+l6mqdsob5+uYmmwEy9z4sbyFX8L7KH8iteB+m+yDzd1Ag87Ablpt7pxKnWMc6ee2BDHu6m+yWmGl5XpUJZvC+ys+4FO/DdCdmi/fx8HL1cvy2DQsuLxtfhfOe9ibbATR3PywT0OB+lT+ZQXE/THeCtrifCMur8nwN5ao8XePEy/OqTHCBxVX+jAXF4jDdicticSIMuCwHZHSNEy/PqzLBBT5WuY8ptBQd+4+Hn14fPn//8KwA6/9O11GGAZjljIyuceLleVUmwMCtKr+5TgGWrgOWLMD4MRlfQwPGPYmW51WZAANPqtQutI+v6Tpg/XNWjzIMwCyPXKBrnHh5XpUJMPCeSk1B+wDL1wHLFmD8tje+hgaM+wstz6syAQb+Uvsn8xxW4X5g/cdiRxkGYJZb3+gaJ16eV2UCDDyk9j+x7bAK9wOrFmD89je+hgaMOwUtz6vyBlhw0imWV+Q3wi/1rMK9wJT34MCUcP9p/94FmlxA4ObleVUmuKVbLK96d1iHVbgft7fg1vQguDjlOk3RlVgVudjV3WQ3gKZusSoT0NItlle9EA6rcD/o/vc4KuFloJxPvsbiQ3UhTo5fkd/X3mQ7oKZesioT1NJLlldso82v/azS/axHC2vljCi4KTqXy/JETTcm5VsD+9qbbAfWVGpWZcJaSs3yirHmVrNK97M2WI0SdkPMIcSpJldjcbU6fifLvvYm24E19aFVmbCWPrS8Yqy5EK3S/awNQqSE3TDFPE1jyTm8/aKQvr65yWbgTDVqVSacpUYtrxhn7lGrdD9ng0cpYTdkV7JPYw0+Fj9G7aN6R3eT3UCa+teqTEhL/1peMdJcwFbpftIGAVPCbsjBl1qWB3f7MYz88+1uV3eT3UCaituqTEhLcVteMdLc3FbpftIGc1PCy0+lS95F56oLXnkC+J7mJpuBM/W9VZlwlr63vGKcufCt0v2cDcKnhN2QanSu5BBDjbEoj5rY1d1kN5Cmorgqb0l7EEXPbzpUTBHT3aT5myikeXg5Dp3CmEt2KdWalH8NdzQ32Sw50/K8KhPOYIie33WoKCKm+zlbFJGH3RBKClMca01jdpk/EGFPc5PNwJkLIpYJZxBEz288VAwR0/2cLYbIw8vT6krN1dfia8pVGUu0q7vJbiDN/RDLhDT4oefnVoofYrqftMUPeXj5Wrhfbu1OwedxSsr1pR3NTTYDZ+6GWCacwQ09f6y44oaY7udscUMRFhc/lTX4xU++xomX51WZEAPD8/zESzE8TPcTsxieCAMxw5EXX+PEy/OqTIiBq3n+dAjF1TDdT8ziaiIMxAxnXnyNEy/PqzIhBs7l+WMeFOfCdD8xi3OJMBAzHHrxNU68PK/KhBi4k+fupABT1Ol/v3990nHxd6B/1qNMAy/DmRdf48TL86pMeIEDeX7vncKrXsPL8K2uo0wDL8ORF1/jxMvzqrzlFcBkAt36Kx9hGO7kxd9B4yXSkhdfROFF1zjx8rwqE15gJIFu4ZUPMAz38jJMuD3KNPAyPPWBr3Hi5XlVJrzALALdiSuXfjDcyyuYeNH72pRFNF7cD2h5XpUJL/CD0D/b57AK9/IynFAdZRp4GW5s42uceHlelQkv2OeH/ufAHVbhXl7RxCvuPLHfuUCTCwBt7ghYJrTBEUL/94EOq3AvbcNjy49KeoGV/RSmnGJyo3f8gtHdvvYm24E0dwssE9LgFqF/239YhXtJTybS2mMjUghTLtnH5Hzl51R3u7qb7AbO3EiwTDiDkQR+CqRcj8F0L2jDWxyV9NtAgRizi6kuB++Tdly/q73JdkDNVQbLBDWoTOCiobgMpntRm1yGp90wFl+Cj766cXmEhPJIhH3tTbYDam5BWCaowYICdxRFgzDdi9qkQUEf6ZqDC6XEMZWkfUxf39xkM2Dm8oTlLeYR5GnkaqPYE6Y7MStvoWDmaTekWP2Yg485RR+VU6AdzU02S8y0PK/KBDM418iNSJEuTPdiNkkXT7shpTjG5EqMYSxZu3ttT3eT3QCayxqWCWiQtSVGKCi2hule0CZb4+nleShTrZNL4zJtO1bl/HhPd5PdAJpbHpYJaLC8kTuYonmY7gVt0jyedkMcYxxjWEYZ1bGM2i0Ru9qbbAfUXBCxTFCDII5c3xRDxHQvapMh8rQbQp1cWG4geftF4Xx1b5O9AJl7IZYJZPDCkVubIoaY7oVsEkOeXgZwlzGNwacQSh2V/caO5iabATOXQiwTzCCFI1c2xQox3YvZZIU8vRz/TimUqbgxTyGHqH5u7Opvsh9gczPEMoENZjjysyrFDDHdC9tkhiItL8XxRZRLcXSNEy/PqzIBBn438seSK36H6V5gJr8TaQBmOauia5x4eV6VCTCwtJGfVSmWhuleYCZLE2kAZjmsomuceHlelbfAIvhW5M98UHwL053A+FtowERaAuOLKMDoGidenldlAgzMKfKnNyjmhOleYCZzEmkAZjmuomuceHlelQkwMKDI9UThpQjQX59+PnN7gvIW9D2OMg3ALOdVdI0TL8+rMgEGJhP5/WwKsPEqYKMJGD+w4otowLiP0PK8KhNg4CORbuG1j7B4FTDD96KOMg3ALPel0TVOvDyvygQYuEWku3HtIyxdBSyZgPHb0vgiGjBuCbQ8r8oEGFhCpJtq5SIOhruBGSbfHmUagFnuSqNrnHh5XpUJMNjpR7qDVi7GYLgbWDYB4zt9vogGjO/0aXlelQkw2OnH/gFBh1W4G5jhsOiopA2n7jsXaHIBwM09AcsEN3hC7H/a22EV7sZdTbjrrmP3Xe1NtgNqbhhY3qJOYBip/zs3h1W4FzV/Cw01T789VGCMNUwlhRiK8hDmXd1NdkvQtDyvygQ0mEkyaMNhle4m7U2klWMZ75ZH8OWa89svCujrm5tsBs5caLBMOIPQJINtHFbpbs4mo+FpNwRfU415+ZZ7zlk5o9zR3GQzcOYehGXCGTwocUlRRAjT3ZxNIsTTb7cnZDfF0cWUi8r5+uYmm4Ez1ycsE86gT4m7jeJPmO7mbPInnnZDDNpnha2hyQbgye0Ky4Qn2FXi6qPoFaa7eZr0iqff8IjjcQXt1b1N9gJlrmRYJpRByRL3JcXJMN1N2eRkPO2GsebRp+BCWH5RKF/d22QvUOYeh2VCGTwucclSRA7T3ZRNIsfTbhh9cNX54MepJHXzdn1zk83Amesflgln0L/E3UzxP0x3czb5H0+7wedS6xSXmw+q026Z3NHcZDNw5t6HZcIZvC9xKVPED9PdnE3ix9PLfbxTiq7WFIpfHjSigN7R3WQ3kObah+Ut6Qm0b+JOpngfpntJK++hkObpxZGXgRi/D9BRno6/r73JdsmaludVmbAG85v4mZRifpjuZm0yP5GWl9v4IsrlNrrGiZfnVZkQA4eb+KPBFYfDdDcxk8OJNBCznErRNU68PK/KhBjY2MRPpRQbw3Q3MZONiTQQsxxL0TVOvDyvyoQYeNXEn5egeBWmu4mZvEqkgZjlXIquceLleVUmxMCcJv68BMWcMN1NzGROIg3ELAdTdI0TL8+rMiEGFjRxQ1GAKRJ0fHh/Dhh/C/of/lGmAZjlYIquceLleVUmwEBoJn4LmgIsXwUsm4Dxgym+iAaMmwktz6syAQZmMtGtvPYhVq4CVkzA+C1ofBENGFcMWp5XZQIMFGOiW3LtM6xeBczwXaSjTAMwyy1odI0TL8+r8hZYBlPIdGOtXMjBcC8w/hYaMJGWwPgiCjC6xomX51WZAIPtfqa7aOWaDIa7gRlm0x5lGoBZdvt0jRMvz6syAQa7/Uw30crFFQx3AwsmYNrD1BTNt+WbzANMLgJYJjBBBHL/EJ/DKtwN03Dyc1TSy4msAtOUbzIPMLkjYJnABEfI/Y87O6zC3TCjCab2rATl6wa2fJN5gMn1AcsEJuhDNnyf5bBKd9M0PLT7qKTd4GKNdRxdiW7ST2b3dDfZDaS5dmCZkAbtyIaDkcMq3U3a5B087QY/VZeqz67UFLSHiO5obrIZOHNbwTLhDLaSDSpxWKW7OZt0haeX5626aSyl+nHyedL+Gbu+uclm4MwlB8uEM0hO5gaiWA6muzmbLIen3TDGOuVQxlLTNEXl1rsdzU02A2fuRlgmnMGNMhcXRY4w3c3ZJEc87YYxxZKnWuvoc9TOxnc0N9kMnLlSYXnLuYBSFe47ilNhupez8h4KZ552w/LPWEgluhTqWJUd247mJpslZ1qeV2XCGUyscE1SVAzT3ZxNKsbTbli+MD5Wl3IaS9a+3b+juclm4MwFDsuEMwhc4XalGBymuzmbDI6n3eBTiM5NU8xvk5MUztc3N9kMnLnbYZlwBrcrXLwUucN0N2eT3PH04he5hrHmuEyImMaozf/Z199kP9Dm8odlQhvkr3AzU+wP0920TfbH01Sg7izhJsPAkXsflglH8L7Cj40U78N0N0eT94m0vCDGF9GIcX+j5XlVJsTA3wp/zLbib5juJmbyN5EGYpZzI7rGiZfnVZkQAxMr/NxIMTFMdxMzmZhIAzHLwRFd48TL86pMiIFTFf7sAsWpMN1NzORUIg3ELCdHdI0TL8+rMiEGdlT4wwsUO8J0NzGTHRV+dMQX0Yhxz6HleVX+J7F3v/7p5ePDw+vx/vV+Cf90/+PDv90///jpy8vN48MPr9/duiHf3jx/+vHjP//369NPb/8r3d58//T6+vT5n68+Ptx/eHheXo23Nz88Pb3+/uK3N/zl6fnvb2/25/8PUEsDBBQAAAAAAGqQNl0W52/FKAEAACgBAAALAAAAX3JlbHMvLnJlbHPvu788P3htbCB2ZXJzaW9uPSIxLjAiIGVuY29kaW5nPSJ1dGYtOCI/PjxSZWxhdGlvbnNoaXBzIHhtbG5zPSJodHRwOi8vc2NoZW1hcy5vcGVueG1sZm9ybWF0cy5vcmcvcGFja2FnZS8yMDA2L3JlbGF0aW9uc2hpcHMiPjxSZWxhdGlvbnNoaXAgVHlwZT0iaHR0cDovL3NjaGVtYXMub3BlbnhtbGZvcm1hdHMub3JnL29mZmljZURvY3VtZW50LzIwMDYvcmVsYXRpb25zaGlwcy9vZmZpY2VEb2N1bWVudCIgVGFyZ2V0PSIveGwvd29ya2Jvb2sueG1sIiBJZD0iUmJhMmFlYTJiZDMwNjRlYTkiIC8+PC9SZWxhdGlvbnNoaXBzPlBLAwQUAAAACABqkDZd9Mrtl9YAAADNAQAAIwAAAHhsL2RyYXdpbmdzL19yZWxzL2RyYXdpbmcxLnhtbC5yZWxzxdE/bsIwFMfxq1hvbxwSQ5IKw8LSFXEB4zw7Vv1PtqHu2Tr0SL1CpYoBpA7dOr3hJ330ld7Xx+d2X50lV0zZBM9h1bRA0MswG685XIp6GmG/2x7RimKCz4uJmVRnfeawlBKfKc1yQSdyEyL66qwKyYmSm5A0jUK+Co20a9sNTfcGPJrk9B7xL2JQykg8BHlx6MsvMJWLSAXISSSNhQOtls5JvBmvb9vtrJrqLJCXmcOxHyfs1+00qGli/cCA0H/v6+76zh2OTK3PG9kz1g3jTx99eMruG1BLAwQUAAAACABqkDZdtGxNF8QBAACcCAAAGgAAAHhsL19yZWxzL3dvcmtib29rLnhtbC5yZWxzzdbNatwwEAfwVzG+d/U1kqwSJ1BKobeS5gVkeWSb2JaRtO3us/XQR+orlKahaNMcclnwRYcRDD/9RwL9+vHz5u60zNU3jGkKa1uzA60rXF3op3Vo62P275r67vbmHmebp7CmcdpSdVrmNbX1mPP2npDkRlxsOoQN19My+xAXm9MhxIFs1j3aAQmnVJFY9qgve1YP5w3f0jF4Pzn8GNxxwTW/0pikfJ4x1dWDjQPmtian+bl2OC1zXX3u2/peKuoFaimlU2BEU1fkaqA84oKXnqfS35UVKmOdaICBQqdBePZG1TK5GFLw+eDC8gwinHJOGHth+YQ2HyN+iWHDmM8f7HAJ8//tv1Iqc3Sysx4aAM6AcnHNHNNoI/Zfc5zW4eV8y62Cp7lH0YMEwQ3QRl+T9z3ExzQi5kvav/KfAyDmct6aNyB977WkAnpvd8Dj5XX0wJQ20gqrAdHvgCcKXmNs55UHIV0PXskd8KBMzyiujOO9dQwsNTvgyYJHBTbaO+yM52CA74CnyvR0BwI61iF20Ei3A54ueB1XFrue9R1wkHoP6TUljwJS3zfWMwbc7OHlmoLnAIF3hmplBWgBTzxy8ce4/Q1QSwMEFAAAAAgAapA2XeKz/Xe7AAAAKgEAACMAAAB4bC93b3Jrc2hlZXRzL19yZWxzL3NoZWV0MS54bWwucmVsc43PO47CMBSF4a1Ytyc3iYCJRnFoaGgRG7Cca8fCL9kGPGubYpY0W6ACgTTFtOeXPun8fv+Mu+osu1LKJngOXdMCIy/DbLzmcClqNcBuGo9kRTHB58XEzKqzPnNYSomfiFku5ERuQiRfnVUhOVFyE5LGKORZaMK+bbeYXg14N9npK9J/xKCUkbQP8uLIlz9gnJO4Ga+BnUTSVDhgtY/xWbumOgvsMHM4qo/NIIXse5o3627YAsNpxLfH0x1QSwMEFAAAAAgAapA2XfWIGJR8AQAAowkAABMAAABbQ29udGVudF9UeXBlc10ueG1szZZLbtswEIavInBbmLSdNE0KywHy2LYB2gtMqJFEhC8Mx458tixypF6hMK0GgRFAebitNhyC4PzfR4IL/np4XJx3zhZrpGSCL8VMTkWBXofK+KYUK64np+J8ufi5iZiKzlmfStEyx69KJd2igyRDRN85WwdywEkGalQEfQcNqvl0eqJ08IyeJ7zNEMvFFdawslxcd4x+h+2cFcXlbt8WVQqI0RoNbIJXa1/tQSahro3GKuiVQ88yRUKoUovIzspcpQPjP+Vg9SKT0Ka3QftTSUKb96TWxPSE+L5GIlNhcQPE38BhKVRnVeKNxSQPfMIcOoTmFh3uxtmHBXLMELFG4BXhDYWIxJsLaF5YeoWKSxPsNFrZd8e++xaawftugbD6wWR8c/Brf549JHIf6C43JpXL7MAyT/lDIhXB/Vb4z+TjIn3Qq8G6BeK+HIzurMyB77KY/2uL/dcw/1+vYV/kaCwix2MR+TwWkZOxiHwZi8jpWETO/rqIyl+u5W9QSwECFAMUAAAACABpkDZdLuHRAogBAACuBQAADwAAAAAAAAAAAAAApIEAAAAAeGwvd29ya2Jvb2sueG1sUEsBAhQDFAAAAAgAaZA2XVDYZLq9AwAAWDIAAA0AAAAAAAAAAAAAAKSBtQEAAHhsL3N0eWxlcy54bWxQSwECFAMUAAAACABpkDZd+lwBWQMDAADaDQAAEwAAAAAAAAAAAAAApIGdBQAAeGwvdGhlbWUvdGhlbWUxLnhtbFBLAQIUAxQAAAAIAGmQNl3Nb1zC6QAAAAcCAAAsAAAAAAAAAAAAAACkgdEIAAB4bC9mZWF0dXJlUHJvcGVydHlCYWcvZmVhdHVyZVByb3BlcnR5QmFnLnhtbFBLAQIUAxQAAAAIAGmQNl0NHrnoZQAAAHMAAAAUAAAAAAAAAAAAAACkgQQKAAB4bC9zaGFyZWRTdHJpbmdzLnhtbFBLAQIUAxQAAAAIAGmQNl1Z2SBkqgcAAOwpAAAYAAAAAAAAAAAAAACkgZsKAAB4bC93b3Jrc2hlZXRzL3NoZWV0MS54bWxQSwECFAMUAAAACABpkDZdMqa456IBAAA2CAAAGAAAAAAAAAAAAAAApIF7EgAAeGwvZHJhd2luZ3MvZHJhd2luZzEueG1sUEsBAhQDFAAAAAgAaZA2Xcu8+QRPAwAAAw8AAB0AAAAAAAAAAAAAAKSBUxQAAHhsL2RyYXdpbmdzL2NoYXJ0cy9jaGFydDEueG1sUEsBAhQDFAAAAAgAaZA2XYUKSXVGAwAAew0AAB0AAAAAAAAAAAAAAKSB3RcAAHhsL2RyYXdpbmdzL2NoYXJ0cy9jaGFydDIueG1sUEsBAhQDFAAAAAgAaZA2XeOSoageCwAApVQAABgAAAAAAAAAAAAAAKSBXhsAAHhsL3dvcmtzaGVldHMvc2hlZXQyLnhtbFBLAQIUAxQAAAAIAGmQNl0/dxdIig8AABYyAAAYAAAAAAAAAAAAAACkgbImAAB4bC93b3Jrc2hlZXRzL3NoZWV0My54bWxQSwECFAMUAAAACABpkDZd4/Daa10JAAAbQgAAGAAAAAAAAAAAAAAApIFyNgAAeGwvd29ya3NoZWV0cy9zaGVldDQueG1sUEsBAhQDFAAAAAgAaZA2XdAc5ktrAgAAywoAABgAAAAAAAAAAAAAAKSBBUAAAHhsL3dvcmtzaGVldHMvc2hlZXQ1LnhtbFBLAQIUAxQAAAAIAGmQNl0vKiP3CwQAAIEWAAAYAAAAAAAAAAAAAACkgaZCAAB4bC93b3Jrc2hlZXRzL3NoZWV0Ni54bWxQSwECFAMUAAAACABpkDZdTmHvifgWAAASaQAAGAAAAAAAAAAAAAAApIHnRgAAeGwvd29ya3NoZWV0cy9zaGVldDcueG1sUEsBAhQDFAAAAAgAaZA2XQ9/W4O+BAAAVyIAABgAAAAAAAAAAAAAAKSBFV4AAHhsL3dvcmtzaGVldHMvc2hlZXQ4LnhtbFBLAQIUAxQAAAAIAGmQNl1ySCyKwigAADN1AQAYAAAAAAAAAAAAAACkgQljAAB4bC93b3Jrc2hlZXRzL3NoZWV0OS54bWxQSwECFAMUAAAAAABqkDZdFudvxSgBAAAoAQAACwAAAAAAAAAAAAAApIEBjAAAX3JlbHMvLnJlbHNQSwECFAMUAAAACABqkDZd9Mrtl9YAAADNAQAAIwAAAAAAAAAAAAAApIFSjQAAeGwvZHJhd2luZ3MvX3JlbHMvZHJhd2luZzEueG1sLnJlbHNQSwECFAMUAAAACABqkDZdtGxNF8QBAACcCAAAGgAAAAAAAAAAAAAApIFpjgAAeGwvX3JlbHMvd29ya2Jvb2sueG1sLnJlbHNQSwECFAMUAAAACABqkDZd4rP9d7sAAAAqAQAAIwAAAAAAAAAAAAAApIFlkAAAeGwvd29ya3NoZWV0cy9fcmVscy9zaGVldDEueG1sLnJlbHNQSwECFAMUAAAACABqkDZd9YgYlHwBAACjCQAAEwAAAAAAAAAAAAAApIFhkQAAW0NvbnRlbnRfVHlwZXNdLnhtbFBLBQYAAAAAFgAWAAsGAAAOkwAAAAA='

def resolve_input(requested,kind):
    path=Path(requested)
    if path.exists():return path
    patterns=['Input Data*.xlsx'] if kind=='data' else ['Input Core assumptions*.xlsx']
    matches=sorted({p for pat in patterns for p in Path.cwd().glob(pat)})
    if len(matches)!=1:raise FileNotFoundError(f'Specify --{ "input-data" if kind=="data" else "core-assumptions"}: found {len(matches)} matching files.')
    return matches[0]


def write_registers(out_dir,records,inp,cfg):
    """Create small, machine-readable run registers, not another output workbook."""
    rows=[];monthly=[]
    for rec in records:
        vals=rec['cols'];row={'case':rec['key'],'alpha':rec['alpha'],'strategy':rec['strategy'],'battery_kWh':rec['battery']}
        for c in layout.SUM_COLS:row['annual_'+c]=float((inp['pv'] if c=='H' else inp['load'] if c=='I' else vals[c]).sum())
        row.update({'omega_min':float(vals['K'].min()),'omega_mean':float(vals['K'].mean()),'omega_max':float(vals['K'].max())})
        row.update(rec['qa']);rows.append(row)
        for m,rowv in enumerate(aggregate_values(inp,vals,'Monthly'),1):
            monthly.append({'case':rec['key'],'alpha':rec['alpha'],'strategy':rec['strategy'],'battery_kWh':rec['battery'],
                            **dict(zip(layout.aggregation_header('Month'),rowv))})
    for name,data in [('Run_Register.csv',rows),('Monthly_Register.csv',monthly)]:
        with open(Path(out_dir)/name,'w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    provenance={'model_version':'v4_alpha_calibration_physical','python':platform.python_version(),'numpy':np.__version__,
      'scipy':scipy.__version__,'input_sha256':inp['input_sha256'],'core_sha256':inp['core_sha256'],
      'settings':asdict(cfg),'calibration':'calendar-day arithmetic mean spot EUR/kWh + alpha * hourly Base load Demand',
      'cases':[{k:v for k,v in x.items() if k not in ('cols','dispatch')} for x in records],
      'note':'C dispatch is computed once per capacity and reused across alpha, because alpha and omega do not enter its cost-only optimization. Technical QA is not economic or field validation.'}
    (Path(out_dir)/'Execution_Metadata.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    return rows


def package_cases(out_dir):
    root=Path(out_dir);zips=[]
    for folder in sorted(root.glob('Alpha_*')):
        if not folder.is_dir():continue
        zp=root.parent/f'{folder.name}_12_Excel_Outputs.zip'
        with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
            for path in sorted(folder.glob('*.xlsx')):z.write(path,arcname=f'{folder.name}/{path.name}')
            for name in ['README.md','Run_Register.csv','Execution_Metadata.json']:
                f=root/name
                if f.exists():z.write(f,arcname=name)
        zips.append(zp)
    allzip=root.parent/'Alpha_Sensitivity_36_Excel_Outputs.zip'
    with zipfile.ZipFile(allzip,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
        for path in sorted(root.rglob('*')):
            if path.is_file():z.write(path,arcname=str(path.relative_to(root)))
    return allzip,zips


def write_readme(out_dir):
    text='''# Alpha sensitivity - 36 calculated Excel outputs\n\n'''
    text+='Calibration: omega_t = mean of the 24 supplied spot prices in the same calendar day (EUR/kWh) + alpha * hourly Base load Demand.\n\n'
    text+='The 36 cases vary alpha (0.20, 0.25, 0.30), strategy (A, B, C), and battery size (10, 15, 20, 30 kWh). No other price year is introduced.\n\n'
    text+='## Workbook sheets\nSummary; Parameters; Model_Notes; Solar_8760_2025; Dispatch; Daily_Summary; Monthly_Summary; QA; Monthly_Profile.\n\n'
    text+='All numerical results are cached in the Excel files, including formula results. Dispatch cells are snapshots of the Python solution: rerun the Python program after input or parameter changes. Editing alpha in Excel alone does not re-optimize the dispatch.\n\n'
    text+='## Critical interpretation notes\n'
    for title,paragraph in layout.NOTES:text+=f'### {title}\n{paragraph}\n\n'
    text+='## Source/model distinction\nThe original EQ1-EQ32 evaluation algebra is retained except where explicitly documented (actual consumption and throughput degradation). AO, AU and BJ require the interpretation stated above; they are not automatically independently additive or pure pre-P2P welfare measures. No buyer participation constraint is added. Negative outcomes are retained and flagged.\n\n'
    text+='## Numerical checks\nThe code checks calibration, hourly site and storage balances, SOC continuity and limits, charging/discharging power, non-simultaneity, and the two stated algebraic identities. A PASS is not a claim that the conceptual economic framework or the original journal conclusions are validated.\n\n'
    text+='## Reproduction\nRun `python build_EQ1_EQ32_AlphaSensitivity_v4.py --input-data "Input Data.xlsx" --core-assumptions "Input Core assumptions.xlsx"`. Supply the two original input workbooks. Dependencies: numpy and scipy. No Google Drive connection, paid solver, spreadsheet engine, or API key is required.\n'
    (Path(out_dir)/'README.md').write_text(text,encoding='utf-8')


def run_pipeline(input_file,core_file,out_dir='Alpha_Sensitivity_36_Outputs',alphas=(.20,.25,.30),strategies=('A','B','C'),batteries=(10,15,20,30),make_zips=True):
    inp,cfg=load_inputs(Path(input_file),Path(core_file));root=Path(out_dir);root.mkdir(parents=True,exist_ok=True)
    if any(not np.isfinite(a) or a<=0 for a in alphas):raise ValueError('Alpha values must be finite and positive.')
    if any(b<=0 for b in batteries):raise ValueError('Battery capacities must be positive.')
    cache={}
    if 'C' in strategies:
        for bat in batteries:
            print(f'Computing hourly rolling C dispatch, {bat:g} kWh...',flush=True)
            cache[bat]=dispatch_c(inp,cfg,bat,progress=True)
    recs=[];template=base64.b64decode(TEMPLATE_BASE64)
    for alpha in alphas:
        for strategy in strategies:
            if strategy not in ('A','B','C'):raise ValueError('Strategies must be A, B or C.')
            for bat in batteries:
                d=cache[bat] if strategy=='C' else dispatch_ab(inp,cfg,alpha,bat,strategy)
                vals,qa=evaluate(inp,cfg,alpha,bat,strategy,d)
                if not qa['technical_pass']:raise RuntimeError(f'Numerical QA failure alpha={alpha}, strategy={strategy}, battery={bat}: {qa}')
                key=f'Alpha_{alpha:.2f}_Strategy_{strategy}_Battery_{bat:g}kWh'
                folder=root/f'Alpha_{alpha:.2f}';folder.mkdir(exist_ok=True)
                write_xlsx(folder/(key+'.xlsx'),template,inp,cfg,alpha,bat,strategy,vals,qa,d)
                recs.append({'key':key,'alpha':alpha,'strategy':strategy,'battery':bat,'cols':vals,'qa':qa})
                print('Saved '+key+'.xlsx',flush=True)
    write_readme(root);write_registers(root,recs,inp,cfg)
    result=package_cases(root) if make_zips else (root,[])
    print(f'Complete: {len(recs)} workbooks. Read Model_Notes and the QA warnings before journal interpretation.',flush=True)
    return result


def main():
    parser=argparse.ArgumentParser(description='36 alpha-calibrated EQ1-EQ32 output workbooks; corrected v4.')
    parser.add_argument('--input-data',default='Input Data.xlsx')
    parser.add_argument('--core-assumptions',default='Input Core assumptions.xlsx')
    parser.add_argument('--output-dir',default='Alpha_Sensitivity_36_Outputs')
    parser.add_argument('--alphas',type=float,nargs='+',default=[.20,.25,.30])
    parser.add_argument('--strategies',nargs='+',choices=['A','B','C'],default=['A','B','C'])
    parser.add_argument('--battery-sizes',type=float,nargs='+',default=[10,15,20,30])
    args,_=parser.parse_known_args()
    return run_pipeline(resolve_input(args.input_data,'data'),resolve_input(args.core_assumptions,'core'),args.output_dir,args.alphas,args.strategies,args.battery_sizes)

if __name__=='__main__':
    main()
