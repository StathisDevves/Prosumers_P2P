# FixedOmega v5: changes from corrected v4

## The change requested
The three values alpha = 0.20 / 0.25 / 0.30 EUR/kWh² are evaluated with an identical, prescribed residential omega profile:
Hours 1–6: 0.55; 7–10: 1.00; 11–16: 0.80; 17–22: 1.35; 23: 0.65; 24: 0.55 EUR/kWh.

The relation omega = daily mean spot + alpha x reference demand is not used in these outputs.
Column K looks up the fixed Omega_Profile table. Column CA tests that profile, not the unused calibration equation.
Column BK still records the daily mean spot price for reference; it no longer determines omega.

## Unchanged numerical model
The starting point is build_EQ1_EQ32_AlphaSensitivity_v4.py, not the pre-review v3.
The Settings, load_inputs, dispatch_ab, solve_storage_window and dispatch_c definitions have been checked against v4.
Controller decisions, objective terms, terminal conditions, SOC continuity, efficiencies, power limits, self-discharge convention,
grid-to-load / grid-to-battery accounting, degradation cost and economic-indicator definitions are retained.
The evaluate function changes only omega and the profile residual/QA label; the remaining evaluation algebra is identical.
Neither buyer-demand caps nor individual-rationality constraints are newly added.
Negative values and diagnostic equilibrium prices are retained without clipping.

## Baseline interpretation
The alpha=0.25 FixedOmega output is the baseline of this fixed-profile experiment.
It is not guaranteed to reproduce the original manuscript outputs because the corrected v4 physical/accounting/controller specification remains.
Keep the previous recalibrated-omega v4 files as a separate experiment. Do not mix their charts or totals with these files.

## Output format and provenance
The original v4 memory-bounded OOXML serializer is retained; the embedded workbook template was edited using artifact_tool.
Omega_Profile is a new tenth sheet. The original hourly columns A:CQ and the summary sheet names/locations are preserved.
Each derived formula has its independently calculated numerical cache from the simulation, so results are readable before opening Excel.
Dispatch data are frozen Python outputs. Changing alpha/omega/input cells in Excel alone does not re-run the controller.
The standalone Python script needs only the two input Excel files, NumPy and SciPy.

## Execution in this delivery
All four unique hourly-rolling Strategy C trajectories were freshly solved (35,040 windows in total),
then used for the three alpha valuations. A/B were evaluated for each alpha and capacity.
The exact same input workbooks and technical Settings were used across alpha values.
Workbook numeric-cache verification is performed separately from numerical model QA.
Technical PASS is not empirical validation of utility calibration or economic welfare accounting.
